const fs=require('node:fs');
const assert=require('node:assert/strict');
const html=fs.readFileSync('work/index.html','utf8');
const moduleSource=fs.readFileSync('work/manager-versioned-persistence.mjs','utf8');
const results=[];
function check(name,fn){try{fn();results.push({name,status:'RÉUSSI'});}catch(error){results.push({name,status:'ÉCHEC',message:error.message});}}
function body(name){const start=html.indexOf(`function ${name}(`);assert.notEqual(start,-1,`missing ${name}`);const a=html.indexOf('\nfunction ',start+10),b=html.indexOf('\nasync function ',start+10),ends=[a,b].filter(index=>index>=0);assert(ends.length,`missing function boundary after ${name}`);return html.slice(start,Math.min(...ends));}
check('Bouton global Marché → Maison et aperçu déjà présents',()=>{assert.match(html,/TRANSFÉRER TOUT MARCHÉ VERS MAISON/);const fn=body('openMarketToHomeTransfer');assert.match(fn,/prepareMarketToHomeTransfer/);assert.match(fn,/Confirmer le transfert/);});
check('Transfert manuel Maison → Marché réutilise le service versionné',()=>{assert.match(body('openReassortOne'),/openSecureIndividualTransfer\(productId,'maison','marche'\)/);});
check('Transfert manuel Marché → Maison réutilise le service versionné',()=>{assert.match(body('openRetourOne'),/openSecureIndividualTransfer\(productId,'marche','maison'\)/);});
check('Pointage manuel existant passe par la proposition sécurisée',()=>{const fn=body('doAdjustStockMM');assert.match(fn,/preparePhysicalStockCount/);assert.doesNotMatch(fn,/saveData\s*\(/);});
check('Confirmation manuelle explicite et double-clic neutralisé',()=>{const fn=body('confirmVersionedStockOperationUI');assert.match(fn,/commitVersionedStockOperation\(proposalId,\{explicit:true\}\)/);assert.match(fn,/button\.disabled=true/);});
check('Pointage et transfert vocal passent par les wrappers du même service',()=>{assert.match(html,/prepareIndividualStockTransfer = args => managerMarketToHomeTransfer\.previewTransfer\(args\)/);assert.match(html,/prepareSinglePhysicalStockCount = args => managerMarketToHomeTransfer\.previewCount\(args\)/);assert.match(html,/commitVersionedStockOperation = \(proposalId, options\) => managerMarketToHomeTransfer\.confirm\(proposalId, options\)/);});
check('Verrou live reste fermé et règle d’écriture générale inchangée',()=>{assert.match(html,/const MANAGER_VERSIONED_WRITES_ENABLED = false/);assert.match(html,/writesEnabled:\s*false/);});
check('Service versionné ne délègue pas à saveData ni stock.adjust',()=>{assert.doesNotMatch(moduleSource,/saveData\s*\(/);assert.doesNotMatch(moduleSource,/stock\.adjust/);assert.match(moduleSource,/expectedRevision:\s*proposal\.revision/);});
check('Voix Google française et écoute existantes toujours présentes',()=>{assert.match(html,/Google français/);assert.match(html,/voiceschanged/);});
const report={total:results.length,passed:results.filter(item=>item.status==='RÉUSSI').length,failed:results.filter(item=>item.status==='ÉCHEC').length,results,kind:'static UI/control check; not a browser visual test'};
console.log(JSON.stringify(report,null,2));if(report.failed)process.exitCode=1;
