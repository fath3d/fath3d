const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const html = fs.readFileSync(require('node:path').join(__dirname, 'index.html'), 'utf8');
function extract(start, end) {
  const a = html.indexOf(start);
  const b = html.indexOf(end, a);
  assert(a >= 0 && b > a, `Missing source range: ${start}`);
  return html.slice(a, b);
}
const saveSource = extract('function saveData() {', '\nlet db = loadData();');
const settleSource = extract('function settleCloudSaveBatch(success) {', '\nfunction saveData() {');
const toastSource = extract('function showToast(msg, success=true) {', '\n\n// ===================== UTILS =====================');

function makeHarness(saveToFirebase) {
  const values = new Map();
  const toast = { textContent: '', className: '' };
  const context = vm.createContext({
    window: { saveToFirebase, managerPersistenceState: () => ({ revision: 7 }) },
    db: { products: [{ id: 1, stocks: { maison: 4, marche: 2 } }], caisseHistory: [] },
    DB_KEY: 'manager',
    localStorage: {
      getItem(key) { return values.has(key) ? values.get(key) : null; },
      setItem(key, value) { values.set(key, String(value)); }
    },
    document: { getElementById(id) { return id === 'toast' ? toast : null; } },
    setTimeout() {},
    console: { warn() {}, error() {} }
  });
  vm.runInContext('let firebaseDataLoaded=true; let pendingSaves=0; let activeCloudSaveCount=0; let cloudSaveBatchFailed=false; let deferredSaveSuccessToasts=[];', context);
  vm.runInContext(settleSource, context);
  vm.runInContext(saveSource, context);
  vm.runInContext(toastSource + '\nwindow.showToast=showToast;', context);
  return { context, toast, values };
}

async function main() {
  const results = [];
  const test = async (name, fn) => { try { await fn(); results.push({ name, status: 'RÉUSSI' }); } catch (error) { results.push({ name, status: 'ÉCHEC', error: error.message }); } };

  await test('Une notification positive attend l’ACK distant avant affichage', async () => {
    let resolve;
    const h = makeHarness(() => new Promise(r => { resolve = r; }));
    const pending = vm.runInContext('saveData()', h.context);
    vm.runInContext("showToast('Stock enregistré',true)", h.context);
    assert.equal(h.toast.textContent, '');
    await Promise.resolve();
    resolve({ ok: true, revision: 8 });
    await pending;
    assert.equal(h.toast.textContent, 'Stock enregistré');
    assert.match(h.toast.className, /success/);
  });

  await test('Un refus de révision supprime le faux succès et conserve une copie de récupération', async () => {
    const h = makeHarness(() => Promise.reject(new Error('MANAGER_REVISION_CONFLICT')));
    const pending = vm.runInContext('saveData()', h.context);
    vm.runInContext("showToast('Transfert enregistré',true)", h.context);
    const result = await pending;
    assert.equal(result.ok, false);
    assert.notEqual(h.toast.textContent, 'Transfert enregistré');
    assert.match(h.toast.textContent, /Conflit de révision/);
    const recovery = JSON.parse(h.values.get('fath3d_manager_pending_remote_saves'));
    assert.equal(recovery.length, 1);
    assert.equal(recovery[0].status, 'conflict');
    assert.ok(recovery[0].payload);
  });

  await test('Une exception synchrone du writer suit aussi le chemin d’échec sans succès apparent', async () => {
    const h = makeHarness(() => { throw new Error('FIREBASE_NOT_READY'); });
    const pending = vm.runInContext('saveData()', h.context);
    vm.runInContext("showToast('Enregistré',true)", h.context);
    const result = await pending;
    assert.equal(result.ok, false);
    assert.notEqual(h.toast.textContent, 'Enregistré');
    assert.match(h.toast.textContent, /Sauvegarde cloud bloquée/);
  });

  const render = extract('function renderStocks(el, actions) {', '\nfunction stockTransferEscape');
  assert.doesNotMatch(render, /onclick="openRetourModal\(\)"/);
  const retour = extract('function openRetourModal() {', '\n// ===================== STOCK BOUTIQUES =====================');
  assert.match(retour, /openMarketToHomeTransfer\(\)/);
  assert.doesNotMatch(retour, /saveData\(\)|\.stocks\.(?:maison|marche)\s*=/);
  const obsoleteBulk = extract('function doReassortMulti() {', '\nfunction openAdjustStock');
  assert.doesNotMatch(obsoleteBulk, /saveData\(\)|\.stocks\.(?:maison|marche)\s*=/);
  results.push({ name: 'Les anciens points d’entrée groupés ne modifient plus directement les stocks et le retour visible est non dupliqué', status: 'RÉUSSI' });

  const failed = results.filter(item => item.status === 'ÉCHEC');
  process.stdout.write(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed.length, firebaseProductionWrites: 0, results }, null, 2) + '\n');
  if (failed.length) process.exitCode = 1;
}
main().catch(error => { console.error(error); process.exitCode = 1; });
