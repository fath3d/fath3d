const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { initializeTestEnvironment, assertFails, assertSucceeds } = require('@firebase/rules-unit-testing');
const { doc, setDoc, getDoc, deleteDoc } = require('firebase/firestore');
const { createManagerVersionedPersistence, createMarketToHomeTransferService } = require('../manager-versioned-persistence.mjs');

const PROJECT='demo-manager-versioning-phase1';
const HOST='127.0.0.1';
const PORT=8785;
const OWNER='owner-phase1';
const OTHER='other-phase1';
const ROOT='fath3d/'+OWNER;
const rulesSource=path.resolve(__dirname,'../firestore.rules.proposed');
const managerSource=path.resolve(__dirname,'../index.html');
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
const originalRules=fs.readFileSync(rulesSource,'utf8');
const managerHtml=fs.readFileSync(managerSource,'utf8');
const transferModuleSource=fs.readFileSync(path.resolve(__dirname,'../manager-versioned-persistence.mjs'),'utf8');
const originalRoot="    match /fath3d/{userId} {\n      allow read, write: if request.auth != null && request.auth.uid == userId;\n    }";
const occurrences=originalRules.split(originalRoot).length-1;
assert.equal(occurrences,1,'Expected the reviewed owner-only root rule exactly once');
const versionedRoot=`    match /fath3d/{userId} {
      function validManagerEnvelope(data) {
        return data is map
          && data.keys().hasOnly(['payload', 'updated', 'revision'])
          && data.keys().hasAll(['payload', 'updated', 'revision'])
          && data.payload is string
          && data.updated is string
          && data.revision is int
          && data.revision >= 1;
      }
      function legacyRevisionInitialization() {
        return !('revision' in resource.data)
          && request.resource.data.revision == 1
          && request.resource.data.payload == resource.data.payload
          && request.resource.data.updated == resource.data.updated
          && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['revision']);
      }
      allow read: if request.auth != null && request.auth.uid == userId;
      allow create: if request.auth != null && request.auth.uid == userId
        && validManagerEnvelope(request.resource.data)
        && request.resource.data.revision == 1;
      allow update: if request.auth != null && request.auth.uid == userId
        && validManagerEnvelope(request.resource.data)
        && (legacyRevisionInitialization()
          || (resource.data.revision is int
            && request.resource.data.revision == resource.data.revision + 1));
      allow delete: if false;
    }`;
const testedRules=originalRules.replace(originalRoot,versionedRoot);

const sample=()=>({
  products:[{id:103,name:'ANGE',stocks:{maison:1,marche:4,artComplices:0,btvero:0}}],
  sales:[{id:'ticket-existing',total:15}],
  depenses:[{id:'expense-existing',amount:7}],
  ventesMarche:[{id:'market-sale-existing',amount:20}],
  recettesManuelles:[{id:'cash-existing',amount:3}],
  nextId:104
});
const envelope=(data,revision)=>({payload:JSON.stringify(data),updated:'2026-10-11T12:00:00.000Z',...(revision==null?{}:{revision})});
let env,ownerDb,otherDb,anonymousDb;
const results=[];

function memoryRecoveryStore(){
  let records=[];
  return {read:()=>records,write:value=>{records=value;},snapshot:()=>JSON.parse(JSON.stringify(records))};
}
function persistence(db,ref,overrides={}){
  const store=overrides.store||memoryRecoveryStore();
  const sdk={
    getDocFromServer:overrides.getDocFromServer||require('firebase/firestore').getDocFromServer,
    runTransaction:overrides.runTransaction||require('firebase/firestore').runTransaction
  };
  return {api:createManagerVersionedPersistence({db,docRef:ref,sdk,recoveryStore:store}),store};
}
function transfer(api,overrides={}){
  return createMarketToHomeTransferService({persistence:api,isWriteEnabled:overrides.isWriteEnabled||(()=>true),now:overrides.now||(()=>Date.now()),createId:overrides.createId||(()=>crypto.randomUUID())});
}
async function seed(data=sample(),revision=1,uid=OWNER){
  const ref=doc(ownerDb,`fath3d/${uid}`);
  await env.withSecurityRulesDisabled(async context=>{
    await setDoc(doc(context.firestore(),`fath3d/${uid}`),envelope(data,revision));
  });
  return ref;
}
async function test(name,fn){
  const start=performance.now();
  try{await env.clearFirestore();await fn();results.push({name,status:'RÉUSSI',ms:Math.round(performance.now()-start)});}
  catch(error){results.push({name,status:'ÉCHEC',message:error&&error.message||String(error),ms:Math.round(performance.now()-start)});}
}

(async()=>{
  try{
    if(process.env.FIRESTORE_EMULATOR_HOST!==`${HOST}:${PORT}`||process.env.GCLOUD_PROJECT!==PROJECT||!PROJECT.startsWith('demo-'))throw new Error('ISOLATION_REQUIRED: only explicit demo emulator is allowed');
    env=await initializeTestEnvironment({projectId:PROJECT,firestore:{host:HOST,port:PORT,rules:testedRules}});
    ownerDb=env.authenticatedContext(OWNER).firestore();
    otherDb=env.authenticatedContext(OTHER).firestore();
    anonymousDb=env.unauthenticatedContext().firestore();

    await test('Versioned Firestore Rules compile while existing 9A Settings Rules are retained',async()=>{
      assert.match(testedRules,/match \/fath3d\/\{userId\}\/settings\/replenishment/);
      assert.equal((await env.withSecurityRulesDisabled(c=>setDoc(doc(c.firestore(),'fath3d/'+OWNER+'/settings/replenishment'),{schemaVersion:1,revision:1,categoryRules:{},lastMutationId:'phase1-seed-marker-001'}))),undefined);
      await assertSucceeds(getDoc(doc(ownerDb,'fath3d/'+OWNER+'/settings/replenishment')));
    });
    await test('Manager wiring uses the tested versioned helper and keeps its live-write prototype gate closed',async()=>{
      assert.match(managerHtml,/import \{[^}]*createManagerVersionedPersistence[^}]*createMarketToHomeTransferService[^}]*\} from '\.\/manager-versioned-persistence\.mjs'/);
      assert.match(managerHtml,/const MANAGER_VERSIONED_WRITES_ENABLED = false/);
      assert.match(managerHtml,/return managerPersistence\.save\(data,\{reason:'manager\.saveData'\}\)/);
      assert.match(managerHtml,/managerPersistence\.save\(next,\{expectedRevision:latest\.revision,reason:'stock\.adjust'\}\)/);
      assert.match(managerHtml,/fath3d_manager_pending_remote_saves/);
      assert.match(managerHtml,/TRANSFÉRER TOUT MARCHÉ VERS MAISON/);
      assert.match(managerHtml,/Confirmer le transfert/);
      assert.match(managerHtml,/window\.managerVersionedWritesEnabled = \(\) => MANAGER_VERSIONED_WRITES_ENABLED/);
      assert.match(transferModuleSource,/const reason\s*=\s*proposal\.kind === 'global_market_to_home' \? 'stock\.transfer\.market_to_home'/);
      assert.match(transferModuleSource,/persistence\.save\(next,\s*\{\s*expectedRevision:\s*proposal\.revision,\s*reason\s*\}\)/);
      assert.doesNotMatch(transferModuleSource,/saveData\s*\(/);
    });
    await test('Owner reads the Manager root; different UID and anonymous access are denied',async()=>{
      const ref=await seed();
      assert((await assertSucceeds(getDoc(ref))).exists());
      await assertFails(getDoc(doc(otherDb,'fath3d/'+OWNER)));
      await assertFails(getDoc(doc(anonymousDb,'fath3d/'+OWNER)));
    });
    await test('Existing legacy document loads without inventing a revision',async()=>{
      const ref=await seed(sample(),null);
      const {api}=persistence(ownerDb,ref);
      const loaded=await api.load();
      assert.equal(loaded.revision,null);
      assert.equal(loaded.revisionInitialized,false);
      assert.deepEqual(loaded.data,sample());
    });
    await test('Revision initialization requires explicit confirmation and leaves payload/stock unchanged',async()=>{
      const data=sample(),ref=await seed(data,null),{api}=persistence(ownerDb,ref);
      await api.load();
      await assert.rejects(api.initializeRevision({confirmed:false}),/CONFIRMATION_REQUIRED/);
      const blocked=(await getDoc(ref)).data();
      assert.equal(blocked.revision,undefined);
      const initialized=await api.initializeRevision({confirmed:true});
      const after=(await getDoc(ref)).data();
      assert.equal(initialized.revision,1);
      assert.equal(initialized.payloadUnchanged,true);
      assert.equal(after.payload,JSON.stringify(data));
      assert.deepEqual(JSON.parse(after.payload).products[0].stocks,data.products[0].stocks);
    });
    await test('Versioned save increments revision once and preserves unrelated stock/finance fields',async()=>{
      const data=sample(),ref=await seed(data,1),{api}=persistence(ownerDb,ref);
      await api.load();
      const next=structuredClone(data);next.products[0].stocks.maison=2;
      const result=await api.save(next);
      const after=(await getDoc(ref)).data(),saved=JSON.parse(after.payload);
      assert.equal(result.revision,2);
      assert.equal(after.revision,2);
      assert.deepEqual(saved.products[0].stocks,{...data.products[0].stocks,maison:2});
      for(const key of ['sales','depenses','ventesMarche','recettesManuelles'])assert.deepEqual(saved[key],data[key],`Unexpected change to ${key}`);
      assert.equal((await api.save(next)).skipped,true);
    });
    await test('Rules reject an old tab write that omits revision',async()=>{
      const data=sample(),ref=await seed(data,1);
      const oldTab=structuredClone(data);oldTab.products[0].stocks.marche=0;
      await assertFails(setDoc(ref,{payload:JSON.stringify(oldTab),updated:'2026-10-11T12:01:00.000Z'}));
      const after=(await getDoc(ref)).data();
      assert.equal(after.revision,1);assert.equal(after.payload,JSON.stringify(data));
    });
    await test('Concurrent saves from the same revision: exactly one transaction succeeds',async()=>{
      const data=sample(),ref=await seed(data,1),a=persistence(ownerDb,ref),b=persistence(ownerDb,ref);
      await Promise.all([a.api.load(),b.api.load()]);
      const one=structuredClone(data);one.products[0].stocks.maison=2;
      const two=structuredClone(data);two.products[0].stocks.marche=3;
      const outcomes=await Promise.allSettled([a.api.save(one),b.api.save(two)]);
      assert.equal(outcomes.filter(item=>item.status==='fulfilled').length,1);
      assert.equal(outcomes.filter(item=>item.status==='rejected').length,1);
      assert.equal((await getDoc(ref)).data().revision,2);
      const rejected=outcomes.find(item=>item.status==='rejected');
      assert.match(rejected.reason.message,/REVISION_CONFLICT|PERMISSION_DENIED/);
    });
    await test('Stale cashier snapshot is refused and retained for recovery; remote ticket/amount is not silently overwritten',async()=>{
      const data=sample(),ref=await seed(data,8),cash=persistence(ownerDb,ref),stock=persistence(ownerDb,ref);
      await Promise.all([cash.api.load(),stock.api.load()]);
      const cashierSnapshot=structuredClone(data);cashierSnapshot.sales.push({id:'ticket-new',total:42});cashierSnapshot.ventesMarche.push({id:'market-sale-new',amount:42});
      const stockSnapshot=structuredClone(data);stockSnapshot.products[0].stocks.maison=2;
      await stock.api.save(stockSnapshot);
      await assert.rejects(cash.api.save(cashierSnapshot),/REVISION_CONFLICT/);
      const recovery=cash.store.snapshot();
      assert.equal(recovery.length,1);
      assert.equal(JSON.parse(recovery[0].payload).sales.at(-1).id,'ticket-new');
      assert.equal(JSON.parse(recovery[0].payload).ventesMarche.at(-1).amount,42);
      const remote=JSON.parse((await getDoc(ref)).data().payload);
      assert.equal(remote.products[0].stocks.maison,2);
      assert.deepEqual(remote.sales,data.sales);
      assert.deepEqual(remote.ventesMarche,data.ventesMarche);
      assert.equal((await getDoc(ref)).data().revision,9);
      await assert.rejects(cash.api.save(cashierSnapshot),/RECOVERY_REQUIRED/);
    });
    await test('Connection failure keeps a durable local recovery copy and performs no cloud write',async()=>{
      const data=sample(),ref=await seed(data,3),store=memoryRecoveryStore();
      const {api}=persistence(ownerDb,ref,{store,runTransaction:async()=>{throw new Error('unavailable');}});
      await api.load();const attempted=structuredClone(data);attempted.products[0].stocks.maison=5;
      await assert.rejects(api.save(attempted),/unavailable/);
      assert.equal(store.snapshot().length,1);
      assert.deepEqual(JSON.parse(store.snapshot()[0].payload),attempted);
      assert.equal((await getDoc(ref)).data().revision,3);
      assert.deepEqual(JSON.parse((await getDoc(ref)).data().payload),data);
    });
    await test('Lost acknowledgement after a committed transaction is marked uncertain and never replayed automatically',async()=>{
      const data=sample(),ref=await seed(data,3),store=memoryRecoveryStore();let transactionCalls=0;
      const realRun=require('firebase/firestore').runTransaction;
      const {api}=persistence(ownerDb,ref,{store,runTransaction:async(db,update)=>{transactionCalls++;await realRun(db,update);throw Object.assign(new Error('acknowledgement lost after commit'),{code:'unavailable'});}});
      await api.load();const attempted=structuredClone(data);attempted.products[0].stocks.maison=6;
      await assert.rejects(api.save(attempted),/acknowledgement lost/);
      assert.equal(store.snapshot()[0].status,'uncertain');
      assert.equal((await getDoc(ref)).data().revision,4);
      assert.deepEqual(JSON.parse((await getDoc(ref)).data().payload),attempted);
      await assert.rejects(api.save(attempted),/RECOVERY_REQUIRED/);
      assert.equal(transactionCalls,1);
    });
    await test('Legacy initialization cannot change tickets, totals, stock, or financial fields',async()=>{
      const data=sample(),ref=await seed(data,null),{api}=persistence(ownerDb,ref);
      await api.load();await api.initializeRevision({confirmed:true});
      const after=(await getDoc(ref)).data();
      assert.equal(after.payload,JSON.stringify(data));
      const restored=JSON.parse(after.payload);
      for(const key of ['products','sales','depenses','ventesMarche','recettesManuelles'])assert.deepEqual(restored[key],data[key]);
    });
    await test('Revision rules reject no-increment, skipped revision, extra envelope fields and delete',async()=>{
      const ref=await seed(sample(),2),raw=(await getDoc(ref)).data();
      await assertFails(setDoc(ref,{...raw,revision:2}));
      await assertFails(setDoc(ref,{...raw,revision:4}));
      await assertFails(setDoc(ref,{...raw,revision:3,unexpected:true}));
      await assertFails(deleteDoc(ref));
      assert.equal((await getDoc(ref)).data().revision,2);
    });
    await test('Other UID cannot write even with a correct-looking next revision',async()=>{
      const data=sample(),ref=await seed(data,1);
      await assertFails(setDoc(doc(otherDb,'fath3d/'+OWNER),{...envelope(data,2)}));
      assert.equal((await getDoc(ref)).data().revision,1);
    });
    await test('Marché → Maison: un produit, aperçu explicite, transaction unique et total conservé',async()=>{
      const data=sample(),ref=await seed(data,4),{api}=persistence(ownerDb,ref),service=transfer(api);
      const preview=await service.preview();assert.equal(preview.ok,true);assert.equal(preview.references,1);assert.equal(preview.pieces,4);assert.equal(preview.items[0].marketBefore,4);assert.equal(preview.items[0].homeBefore,1);assert.equal(preview.items[0].homeAfter,5);assert.equal(preview.revision,4);
      await assert.rejects(()=>service.confirm(preview.proposalId),/EXPLICIT_CONFIRMATION_REQUIRED/);assert.equal((await getDoc(ref)).data().revision,4);
      const done=await service.confirm(preview.proposalId,{explicit:true});assert.equal(done.status,'executed');assert.equal(done.writePerformed,true);assert.equal(done.revision,5);
      const after=(await getDoc(ref)).data(),saved=JSON.parse(after.payload);assert.equal(saved.products[0].stocks.maison,5);assert.equal(saved.products[0].stocks.marche,0);assert.equal(5+0,1+4);
      for(const key of ['sales','depenses','ventesMarche','recettesManuelles'])assert.deepEqual(saved[key],data[key]);
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_PROPOSAL_INVALID/);assert.equal((await getDoc(ref)).data().revision,5);
    });
    await test('Marché → Maison: 450 produits transférés intégralement dans une transaction révisionnée',async()=>{
      const data=sample();data.products=Array.from({length:450},(_,i)=>({id:10000+i,name:'PRODUIT '+i,stocks:{maison:i%7,marche:i%5}}));
      const ref=await seed(data,10),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.preview();
      assert.equal(preview.references,360);assert.equal(preview.pieces,900);const result=await service.confirm(preview.proposalId,{explicit:true});assert.equal(result.references,360);assert.equal(result.pieces,900);assert.equal(result.revision,11);
      const saved=JSON.parse((await getDoc(ref)).data().payload);assert.equal(saved.products.length,450);
      for(let i=0;i<450;i++){const before=data.products[i],after=saved.products[i];assert.equal(after.stocks.maison,before.stocks.maison+before.stocks.marche);assert.equal(after.stocks.marche,0);assert.equal(after.stocks.maison+after.stocks.marche,before.stocks.maison+before.stocks.marche);}
      for(const key of ['sales','depenses','ventesMarche','recettesManuelles'])assert.deepEqual(saved[key],data[key]);
    });
    await test('Marché vide: transfert sans opération et sans incrément de révision',async()=>{
      const data=sample();data.products.forEach(p=>p.stocks.marche=0);const ref=await seed(data,2),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.preview();
      assert.equal(preview.noOp,true);assert.equal(preview.references,0);assert.equal(preview.pieces,0);assert.equal((await getDoc(ref)).data().revision,2);
    });
    await test('Maison déjà positive: la quantité Maison est additionnée, non remplacée',async()=>{
      const data=sample();data.products[0].stocks.maison=12;data.products[0].stocks.marche=8;const ref=await seed(data,1),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.preview();
      assert.equal(preview.items[0].homeAfter,20);const done=await service.confirm(preview.proposalId,{explicit:true});assert.equal(done.status,'executed');const saved=JSON.parse((await getDoc(ref)).data().payload);assert.equal(saved.products[0].stocks.maison,20);assert.equal(saved.products[0].stocks.marche,0);
    });
    await test('Annulation explicite: aucun commit ni consommation de stock',async()=>{
      const data=sample(),ref=await seed(data,3),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.preview();
      assert.equal(service.cancel(preview.proposalId,{explicit:true}).writePerformed,false);assert.equal((await getDoc(ref)).data().revision,3);assert.deepEqual(JSON.parse((await getDoc(ref)).data().payload),data);
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_PROPOSAL_INVALID/);
    });
    await test('Double clic concurrent: le verrou local n’autorise qu’une confirmation',async()=>{
      const data=sample(),ref=await seed(data,1),{api}=persistence(ownerDb,ref);let release,blockNext=false,loadCalls=0;
      const gate=new Promise(resolve=>{release=resolve;});const wrapped={load:async()=>{loadCalls++;if(blockNext&&loadCalls===2)await gate;return api.load();},save:(...args)=>api.save(...args)};
      const service=transfer(wrapped),preview=await service.preview();blockNext=true;const first=service.confirm(preview.proposalId,{explicit:true});
      await new Promise(resolve=>setImmediate(resolve));await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_EXECUTION_IN_PROGRESS/);release();assert.equal((await first).status,'executed');assert.equal((await getDoc(ref)).data().revision,2);
    });
    await test('Conflit de révision après aperçu: transfert bloqué sans écraser le nouvel état',async()=>{
      const data=sample(),ref=await seed(data,1),first=persistence(ownerDb,ref),concurrent=persistence(ownerDb,ref),service=transfer(first.api);const preview=await service.preview();await concurrent.api.load();const changed=structuredClone(data);changed.products[0].stocks.maison=9;await concurrent.api.save(changed,{expectedRevision:1});
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/MANAGER_REVISION_CONFLICT/);const remote=JSON.parse((await getDoc(ref)).data().payload);assert.equal(remote.products[0].stocks.maison,9);assert.equal(remote.products[0].stocks.marche,4);assert.equal((await getDoc(ref)).data().revision,2);
    });
    await test('Erreur réseau transactionnelle: pas de succès fictif, pas de rejeu et document inchangé',async()=>{
      const data=sample(),ref=await seed(data,6);let calls=0;const {api,store}=persistence(ownerDb,ref,{runTransaction:async()=>{calls++;throw Object.assign(new Error('unavailable'),{code:'unavailable'});}});const service=transfer(api),preview=await service.preview();
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/unavailable/);assert.equal(calls,1);assert.equal(store.snapshot().length,1);assert.equal(store.snapshot()[0].status,'uncertain');
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_PROPOSAL_INVALID/);assert.equal(calls,1);const remote=(await getDoc(ref)).data();assert.equal(remote.revision,6);assert.deepEqual(JSON.parse(remote.payload),data);
    });
    await test('Révision absente: aperçu bloqué et aucune initialisation implicite',async()=>{
      const ref=await seed(sample(),null),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.preview();assert.equal(preview.ok,false);assert(preview.anomalies.some(item=>item.code==='MANAGER_REVISION_NOT_INITIALIZED'));assert.equal((await getDoc(ref)).data().revision,undefined);
    });
    await test('Quantités inconnues, négatives, incohérentes et IDs dupliqués bloquent tout transfert',async()=>{
      const cases=[
        {name:'missing market',mutate:data=>delete data.products[0].stocks.marche},
        {name:'negative',mutate:data=>{data.products[0].stocks.marche=-1;}},
        {name:'fraction',mutate:data=>{data.products[0].stocks.maison=1.5;}},
        {name:'duplicate id',mutate:data=>{data.products.push(structuredClone(data.products[0]));}}
      ];
      for(const item of cases){const data=sample();item.mutate(data);const ref=await seed(data,1),{api}=persistence(ownerDb,ref),preview=await transfer(api).preview();assert.equal(preview.ok,false,item.name);assert(preview.anomalies.length>0,item.name);assert.equal((await getDoc(ref)).data().revision,1,item.name);}
    });
    await test('Verrou de production fermé: aperçu permis mais confirmation sans transaction',async()=>{
      const data=sample(),ref=await seed(data,1),{api}=persistence(ownerDb,ref);let tx=0;const monitored={load:(...args)=>api.load(...args),save:(...args)=>{tx++;return api.save(...args);}};const service=transfer(monitored,{isWriteEnabled:()=>false}),preview=await service.preview();
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/MANAGER_VERSIONED_WRITES_DISABLED/);assert.equal(tx,0);assert.equal((await getDoc(ref)).data().revision,1);assert.deepEqual(JSON.parse((await getDoc(ref)).data().payload),data);
    });
    await test('Transfert individuel Maison → Marché: aperçu, confirmation explicite et total conservé',async()=>{
      const data=sample();data.products[0].stocks.maison=3;const ref=await seed(data,7),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.previewTransfer({productId:data.products[0].id,quantity:2,source:'maison',destination:'marche'});
      assert.equal(preview.ok,true);assert.equal(preview.operation,'individual_transfer');assert.equal(preview.items[0].maisonBefore,3);assert.equal(preview.items[0].maisonAfter,1);assert.equal(preview.items[0].marcheAfter,6);assert.equal(preview.items[0].totalBefore,7);
      const result=await service.confirm(preview.proposalId,{explicit:true});assert.equal(result.status,'executed');assert.equal(result.writePerformed,true);assert.equal(result.items[0].homeAfter,1);assert.equal(result.items[0].marketAfter,6);
      const saved=JSON.parse((await getDoc(ref)).data().payload);assert.equal(saved.products[0].stocks.maison,1);assert.equal(saved.products[0].stocks.marche,6);assert.equal(saved.products[0].stocks.maison+saved.products[0].stocks.marche,7);
    });
    await test('Transfert individuel Marché → Maison: stock source insuffisant bloqué sans écriture',async()=>{
      const data=sample();data.products[0].stocks.marche=1;const ref=await seed(data,2),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.previewTransfer({productId:data.products[0].id,quantity:2,source:'marche',destination:'maison'});
      assert.equal(preview.ok,false);assert.equal(preview.anomalies[0].code,'INSUFFICIENT_STOCK');assert.equal((await getDoc(ref)).data().revision,2);assert.deepEqual(JSON.parse((await getDoc(ref)).data().payload),data);
    });
    await test('Transfert individuel Marché → Maison: annulation sans écriture puis rejeu refusé',async()=>{
      const data=sample(),ref=await seed(data,3),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.previewTransfer({productId:data.products[0].id,quantity:3,source:'marche',destination:'maison'});
      assert.equal(service.cancel(preview.proposalId,{explicit:true}).writePerformed,false);assert.equal((await getDoc(ref)).data().revision,3);await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_PROPOSAL_INVALID/);
    });
    await test('Pointage physique vocalisé ciblé: une seule localisation, le stock opposé est préservé',async()=>{
      const data=sample(),ref=await seed(data,5),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.previewCount({productId:data.products[0].id,location:'maison',quantity:9});
      assert.equal(preview.ok,true);assert.equal(preview.operation,'physical_count');assert.equal(preview.items[0].homeAfter,9);assert.equal(preview.items[0].marketAfter,4);
      const result=await service.confirm(preview.proposalId,{explicit:true});assert.equal(result.status,'executed');const saved=JSON.parse((await getDoc(ref)).data().payload);assert.equal(saved.products[0].stocks.maison,9);assert.equal(saved.products[0].stocks.marche,4);
    });
    await test('Pointage manuel Maison + Marché atomique; zéro autorisé et total contrôlé',async()=>{
      const data=sample(),ref=await seed(data,8),{api}=persistence(ownerDb,ref),service=transfer(api),preview=await service.previewCounts({productId:data.products[0].id,maison:0,marche:0});
      assert.equal(preview.ok,true);assert.equal(preview.items[0].totalAfter,0);const result=await service.confirm(preview.proposalId,{explicit:true});assert.equal(result.writePerformed,true);const saved=JSON.parse((await getDoc(ref)).data().payload);assert.equal(saved.products[0].stocks.maison,0);assert.equal(saved.products[0].stocks.marche,0);
    });
    await test('Comptage identique: aucune transaction ni révision fictive',async()=>{
      const data=sample(),ref=await seed(data,9),{api}=persistence(ownerDb,ref);let calls=0;const service=transfer({load:(...args)=>api.load(...args),save:(...args)=>{calls++;return api.save(...args);}}),preview=await service.previewCount({productId:data.products[0].id,location:'maison',quantity:data.products[0].stocks.maison});
      assert.equal(preview.noOp,true);assert.equal(calls,0);assert.equal((await getDoc(ref)).data().revision,9);
    });
    await test('Conflit de révision pendant transfert individuel: aucun écrasement',async()=>{
      const data=sample(),ref=await seed(data,1),first=persistence(ownerDb,ref),other=persistence(ownerDb,ref),service=transfer(first.api),preview=await service.previewTransfer({productId:data.products[0].id,quantity:1,source:'maison',destination:'marche'});await other.api.load();const changed=structuredClone(data);changed.products[0].stocks.marche=7;await other.api.save(changed,{expectedRevision:1});
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/MANAGER_REVISION_CONFLICT/);const saved=JSON.parse((await getDoc(ref)).data().payload);assert.equal(saved.products[0].stocks.marche,7);assert.equal(saved.products[0].stocks.maison,1);assert.equal((await getDoc(ref)).data().revision,2);
    });
    await test('Erreur réseau de pointage conservée comme résultat incertain sans rejeu',async()=>{
      const data=sample(),ref=await seed(data,2);let calls=0;const {api,store}=persistence(ownerDb,ref,{runTransaction:async()=>{calls++;throw Object.assign(new Error('unavailable'),{code:'unavailable'});}}),service=transfer(api),preview=await service.previewCount({productId:data.products[0].id,location:'marche',quantity:0});
      await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/unavailable/);assert.equal(calls,1);assert.equal(store.snapshot()[0].status,'uncertain');await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_PROPOSAL_INVALID/);assert.equal(calls,1);assert.equal((await getDoc(ref)).data().revision,2);
    });
    await test('Direction ou quantité non valide et révision absente refusées',async()=>{
      const data=sample(),ref=await seed(data,1),{api}=persistence(ownerDb,ref),service=transfer(api);await assert.rejects(()=>service.previewTransfer({productId:data.products[0].id,quantity:1,source:'maison',destination:'maison'}),/TRANSFER_DIRECTION_INVALID/);assert.equal((await service.previewTransfer({productId:data.products[0].id,quantity:0,source:'maison',destination:'marche'})).ok,false);assert.equal((await service.previewCount({productId:data.products[0].id,location:'marche',quantity:-1})).ok,false);
      const unversioned=await seed(sample(),null),{api:unversionedApi}=persistence(ownerDb,unversioned);const missing=await transfer(unversionedApi).previewCount({productId:sample().products[0].id,location:'maison',quantity:0});assert.equal(missing.ok,false);assert.equal(missing.anomalies[0].code,'MANAGER_REVISION_NOT_INITIALIZED');
    });
  } catch(error) {
    results.push({name:'Initialization / emulator / Rules compilation',status:'ÉCHEC',message:error&&error.message||String(error)});
  } finally {
    if(env) await env.cleanup();
    const report={projectId:PROJECT,emulator:`${HOST}:${PORT}`,productionFirebaseWrites:0,mainOrRulesProductionModified:false,rulesSourceSha256:hash(originalRules),versionedRulesSha256:hash(testedRules),managerModule:'../manager-versioned-persistence.mjs',total:results.length,passed:results.filter(x=>x.status==='RÉUSSI').length,failed:results.filter(x=>x.status==='ÉCHEC').length,results};
    const output=path.join(__dirname,'manager-versioning-results.json');fs.writeFileSync(output,JSON.stringify(report,null,2));
    console.log(JSON.stringify(report,null,2));
    if(report.failed)process.exitCode=1;
  }
})();
