const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

const htmlPath = path.resolve(__dirname, '../index.html');
const source = fs.readFileSync(htmlPath, 'utf8');
const output = path.join(__dirname, 'test-results');
fs.mkdirSync(output, { recursive: true });

function extractFunction(name, nextMarker) {
  const start = source.indexOf(`function ${name}(`);
  const asyncStart = source.indexOf(`async function ${name}(`);
  const actualStart = start < 0 || (asyncStart >= 0 && asyncStart < start) ? asyncStart : start;
  assert.ok(actualStart >= 0, `Missing real Manager function ${name}`);
  const end = source.indexOf(nextMarker, actualStart);
  assert.ok(end > actualStart, `Missing end marker for ${name}`);
  return source.slice(actualStart, end).trim();
}

const escapeFn = extractFunction('stockTransferEscape', '\nasync function openMarketToHomeTransfer');
const previewFn = extractFunction('openMarketToHomeTransfer', '\nasync function confirmMarketToHomeTransferUI');
const confirmFn = extractFunction('confirmMarketToHomeTransferUI', '\nfunction cancelMarketToHomeTransferUI');
const cancelFn = extractFunction('cancelMarketToHomeTransferUI', '\nfunction syncStickyHeaders');

const bootstrap = `
  const document = window.document;
  const db = { products: [{ id: 1001, name: 'ANGE SYNTHÉTIQUE', stocks: { maison: 2, marche: 3 } }] };
  let currentPage = 'stocks';
  let mockWriteCalls = 0;
  let mockCancelCalls = 0;
  let resolveWrite;
  window.prepareMarketToHomeTransfer = async () => ({
    ok: true, noOp: false, proposalId: 'demo-proposal-1', revision: 7,
    references: 1, pieces: 3,
    items: [{ id: 1001, name: 'ANGE SYNTHÉTIQUE', marketBefore: 3, homeBefore: 2, homeAfter: 5, totalBefore: 5 }]
  });
  window.managerVersionedWritesEnabled = () => true;
  window.commitMarketToHomeTransfer = async (id, options) => {
    if (id !== 'demo-proposal-1' || options.explicit !== true) throw new Error('BAD_MOCK_CONFIRMATION');
    mockWriteCalls++;
    return new Promise(resolve => { resolveWrite = () => resolve({ references: 1, pieces: 3, revision: 8, items: [{ id: 1001, homeAfter: 5 }] }); });
  };
  window.abortMarketToHomeTransfer = (id, options) => { if (options.explicit === true) mockCancelCalls++; };
  window.showToast = (message, success) => { document.getElementById('toast').textContent = message; document.getElementById('toast').dataset.success = String(success); };
  window.render = () => {};
  window.openModal = markup => { const modal=document.getElementById('modal'); modal.hidden=false; document.getElementById('modal-content').innerHTML=markup; };
  window.closeModal = () => { document.getElementById('modal').hidden=true; };
  window.stockTransferEscape = stockTransferEscape;
  window.openMarketToHomeTransfer = openMarketToHomeTransfer;
  window.confirmMarketToHomeTransferUI = confirmMarketToHomeTransferUI;
  window.cancelMarketToHomeTransferUI = cancelMarketToHomeTransferUI;
  window.__mockState = () => ({ mockWriteCalls, mockCancelCalls, stocks: db.products[0].stocks });
  window.__resolveWrite = () => resolveWrite && resolveWrite();
`;

const shell = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Validation isolée Étape 8</title>
<style>
  *{box-sizing:border-box}body{font:16px Arial,sans-serif;margin:0;padding:20px;background:#f4f5f7;color:#18212f}
  .toolbar{display:flex;gap:8px;flex-wrap:wrap}.btn{padding:10px 14px;border:0;border-radius:6px;cursor:pointer}.primary,.btn-primary{background:#3157d5;color:#fff}.secondary,.btn-secondary{background:#ddd}
  #modal{position:fixed;inset:0;background:#0008;display:grid;place-items:center;padding:16px}#modal[hidden]{display:none}
  .dialog{background:white;padding:20px;border-radius:12px;width:min(900px,100%);max-height:90vh;overflow:auto;box-shadow:0 10px 40px #0004}
  table{border-collapse:collapse;min-width:600px;width:100%}th,td{padding:8px;border-bottom:1px solid #ddd}#table-wrap{overflow:auto;max-width:100%}
  .modal-actions{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;margin-top:16px}.modal-title{font-size:20px;font-weight:bold;margin-bottom:12px}
  @media(max-width:500px){body{padding:12px}.dialog{padding:14px}.modal-actions .btn{flex:1}}
</style></head><body><p>TEST ISOLÉ — DONNÉES SYNTHÉTIQUES — ADAPTATEUR MOCK UNIQUEMENT</p>
<div class="toolbar"><button id="open-transfer" class="btn primary" onclick="openMarketToHomeTransfer()">⇩ TRANSFÉRER TOUT MARCHÉ VERS MAISON</button></div>
<div id="toast" role="status"></div><section id="modal" hidden><div class="dialog"><div id="modal-content"></div></div></section>
</body></html>`;

(async () => {
  const browser = await chromium.launch({ headless: true });
  try {
    for (const viewport of [
      { name: 'pc', width: 1366, height: 768 },
      { name: 'tablet', width: 768, height: 1024 },
      { name: 'mobile', width: 390, height: 844 }
    ]) {
      const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height } });
      page.on('pageerror', error => console.error(`${viewport.name} page error: ${error.message}`));
      await page.setContent(shell);
      await page.addScriptTag({ content: `${escapeFn}\n${previewFn}\n${confirmFn}\n${cancelFn}\n${bootstrap}` });
      await page.locator('#open-transfer').evaluate(button => { button.onclick = () => window.openMarketToHomeTransfer(); });
      await page.locator('#open-transfer').click();
      await page.locator('#modal-content .modal-title').waitFor({ state: 'visible' });
      assert.match(await page.locator('#modal-content .modal-title').innerText(), /Aperçu.*Marché vers Maison/);
      assert.match(await page.locator('#modal-content').innerText(), /1 références.*3 pièces/s);
      assert.match(await page.locator('#modal-content').innerText(), /2 → 5/);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, `${viewport.name}: horizontal page overflow`);
      await page.screenshot({ path: path.join(output, `step8-transfer-${viewport.name}.png`), fullPage: true });

      await page.locator('#modal-content .btn-primary').click();
      await page.evaluate(() => window.confirmMarketToHomeTransferUI('demo-proposal-1'));
      assert.equal(await page.evaluate(() => window.__mockState().mockWriteCalls), 1, `${viewport.name}: duplicate confirmation`);
      await page.evaluate(() => window.__resolveWrite());
      await page.getByText(/Transfert terminé/).waitFor();
      assert.equal(await page.evaluate(() => window.__mockState().stocks.maison), 5);
      await page.close();
    }

    const cancelPage = await browser.newPage();
    cancelPage.on('pageerror', error => console.error(`cancel page error: ${error.message}`));
    await cancelPage.setContent(shell);
    await cancelPage.addScriptTag({ content: `${escapeFn}\n${previewFn}\n${confirmFn}\n${cancelFn}\n${bootstrap}` });
    await cancelPage.locator('#open-transfer').evaluate(button => { button.onclick = () => window.openMarketToHomeTransfer(); });
    await cancelPage.locator('#open-transfer').click();
    await cancelPage.locator('#modal-content .btn-secondary').click();
    assert.equal(await cancelPage.evaluate(() => window.__mockState().mockWriteCalls), 0);
    assert.equal(await cancelPage.evaluate(() => window.__mockState().mockCancelCalls), 1);
    await cancelPage.screenshot({ path: path.join(output, 'step8-transfer-cancelled.png'), fullPage: true });
    await cancelPage.close();
    console.log(JSON.stringify({ status: 'RÉUSSI', viewports: ['pc','tablet','mobile'], screenshots: 4, testKind: 'Chromium render of actual extracted Manager transfer handlers with synthetic data and mocked persistence' }, null, 2));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
