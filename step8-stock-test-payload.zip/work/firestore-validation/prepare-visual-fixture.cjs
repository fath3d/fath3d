const fs = require('node:fs');
const path = require('node:path');

const sourcePath = path.resolve(__dirname, '../index.html');
const html = fs.readFileSync(sourcePath, 'utf8');
const scriptIds = [
  'jarvis-security-step2',
  'jarvis-write-broker-step6',
  'jarvis-consultation-step5a',
  'jarvis-replenishment-9a',
  'jarvis-replenishment-9a3',
  'jarvis-replenishment-9a4',
  'jarvis-consultation-step5b',
  'jarvis-text-step4'
];
const script = id => {
  const match = html.match(new RegExp('<script id="' + id + '">([\\s\\S]*?)<\\/script>'));
  if (!match) throw new Error('Required Manager module is missing: ' + id);
  return match[1];
};
const style = html.match(/<style>([\s\S]*?)<\/style>/);
const uiStyle = html.match(/<style id="jarvis-replenishment-9a4-style">([\s\S]*?)<\/style>/);
if (!style || !uiStyle) throw new Error('Required Manager styles are missing');

const categories = [
  'AUTRE', "BOUCLE D'OREILLES", 'COLORIAGE', 'DESTOCKAGE', 'FETE PERE',
  'FIGURINE', 'FIN D ANNEE', 'FLEXIBLE', 'HALLOWEEN', 'HUEFORGE', 'LAMPES',
  'MARQUE PAGE', 'MINIMAUX', 'PANIER 3E', 'PANIER 4€', 'PANIER 5€',
  'PANIER 6€', 'PANIER MINI DRAGON 3€', 'PORTE CLEFS'
];
const data = {
  products: categories.map((categorie, index) => ({
    id: 91000 + index,
    name: index === 9 ? 'ANGE TEST SYNTHÉTIQUE' : 'PRODUIT TEST ' + (index + 1),
    categorie,
    stocks: { maison: 2, marche: 1 }
  })),
  sales: [],
  caisseHistory: [],
  urssafDeclarations: []
};
const chat = '<button id="jarvis-text-open">Jarvis texte</button>' +
  '<div id="jarvis-text-backdrop" hidden></div>' +
  '<section id="jarvis-text-panel" hidden><button id="jarvis-text-close">Fermer</button>' +
  '<button id="jarvis-text-reset">Nouvelle conversation</button><div id="jarvis-text-messages"></div>' +
  '<div id="jarvis-text-status"></div><form id="jarvis-text-form"><input id="jarvis-text-input" aria-label="Message à Jarvis">' +
  '<button id="jarvis-text-send">Envoyer</button></form></section>';
const csp = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; form-action 'none'; base-uri 'none'";
const proofScript = `
  window.__testCounters = () => {
    const runtime = window.JarvisReplenishment9A3Runtime;
    let mockCalls = 0;
    if (runtime && typeof runtime.getMockAdapter === 'function') mockCalls = runtime.getMockAdapter().getWriteCount();
    return {
      mockCalls,
      writesEnabled: window.JarvisSecurity.getState().writesEnabled,
      firebaseSdkLoaded: typeof window.firebase !== 'undefined' || typeof window.firebaseReady !== 'undefined',
      externalScripts: [...document.scripts].filter(item => item.src).length,
      syntheticStocksUnchanged: db.products.every(item => item.stocks.maison === 2 && item.stocks.marche === 1),
      overflow: document.documentElement.scrollWidth > window.innerWidth
    };
  };
`;
const page = '<!doctype html><html lang="fr"><head><meta charset="utf-8">' +
  '<meta name="viewport" content="width=device-width,initial-scale=1">' +
  '<meta http-equiv="Content-Security-Policy" content="' + csp + '">' +
  '<title>Jarvis 9A — test isolé synthétique</title><style>' + style[1] + uiStyle[1] +
  'body{padding:16px}.main{margin:0;width:100%;padding:0}#jarvis-text-panel{position:static;max-width:600px}</style></head>' +
  '<body><main class="main"><p>TEST ISOLÉ — DONNÉES SYNTHÉTIQUES — MOCK UNIQUEMENT — aucune connexion réseau</p>' +
  '<div id="topbar-actions"></div><div id="content"></div>' + chat +
  '<output id="test-proof" hidden></output>' +
  '<script>var db=' + JSON.stringify(data) + ';window.JarvisGateway={getState:()=>({writesEnabled:false,persistentConversation:false,firebaseDirectAccess:false}),send:async()=>{throw new Error("Gateway disabled in isolated fixture");}};</script>' +
  scriptIds.map(id => '<script data-source="' + id + '">' + script(id) + '</script>').join('') +
  '<script>' + proofScript + 'JarvisReplenishment9A4.render(document.getElementById("content"),document.getElementById("topbar-actions"),()=>db);</script>' +
  '</body></html>';

const outputPath = path.join(__dirname, 'visual-9a-fixture.html');
fs.writeFileSync(outputPath, page, 'utf8');
console.log('Prepared isolated fixture from work/index.html: ' + outputPath);
