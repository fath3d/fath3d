const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');

const fixture = path.join(__dirname, 'visual-9a-fixture.html');
const evidenceDir = path.join(__dirname, 'test-results');
if (!fs.existsSync(fixture)) throw new Error('Run prepare-visual-fixture.cjs first');
fs.mkdirSync(evidenceDir, { recursive: true });

(async () => {
  const browser = await chromium.launch({ headless: true });
  const outcomes = [];
  try {
    for (const viewport of [
      { name: 'desktop', width: 1440, height: 900 },
      { name: 'tablet', width: 820, height: 1180 },
      { name: 'phone', width: 390, height: 844 }
    ]) {
      const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height } });
      const externalRequests = [];
      page.on('request', request => {
        if (!request.url().startsWith('file:')) externalRequests.push(request.url());
      });
      await page.goto(pathToFileURL(fixture).href);
      const category = page.locator('[data-testid="r9-category"]');
      await category.waitFor({ state: 'visible' });
      assert.match(await page.locator('[data-testid="r9-mode"]').innerText(), /non enregistrées/i);
      assert.equal(await category.locator('option').count(), 19, 'All 19 synthetic categories should render');
      await category.selectOption({ label: 'HUEFORGE' });
      assert.match(await page.locator('[data-testid="r9-value-targetStock"]').innerText(), /1/);
      await page.screenshot({ path: path.join(evidenceDir, '9a-' + viewport.name + '.png'), fullPage: true });

      await page.locator('[data-testid="r9-enable"]').click();
      await page.locator('[data-testid="r9-field"]').selectOption('targetStock');
      await page.locator('[data-testid="r9-quantity"]').fill('2');
      await page.locator('[data-testid="r9-propose"]').click();
      await page.locator('[data-testid="r9-proposal"]').waitFor({ state: 'visible' });
      assert.match(await page.locator('[data-testid="r9-old"]').innerText(), /1/);
      assert.match(await page.locator('[data-testid="r9-new"]').innerText(), /2/);
      await page.locator('[data-testid="r9-cancel"]').click();
      assert.match(await page.locator('[data-testid="r9-status"]').innerText(), /annulée/i);
      let proof = await page.evaluate(() => window.__testCounters());
      assert.equal(proof.mockCalls, 0, 'Cancellation must not write even to the mock adapter');
      assert.equal(proof.writesEnabled, false);
      assert.equal(proof.firebaseSdkLoaded, false);
      assert.equal(proof.externalScripts, 0);
      assert.equal(proof.syntheticStocksUnchanged, true);

      await page.locator('[data-testid="r9-quantity"]').fill('2');
      await page.locator('[data-testid="r9-propose"]').click();
      await page.locator('[data-testid="r9-confirm"]').click();
      await page.getByText(/MODE MOCK/i).waitFor({ state: 'visible' });
      proof = await page.evaluate(() => window.__testCounters());
      assert.equal(proof.mockCalls, 1, 'One explicit mock confirmation should call the mock once');
      assert.equal(proof.writesEnabled, false);
      assert.equal(proof.firebaseSdkLoaded, false);
      assert.equal(proof.externalScripts, 0);
      assert.equal(proof.syntheticStocksUnchanged, true);
      assert.deepEqual(externalRequests, [], 'The fixture must not make network requests');
      if (viewport.width <= 820) assert.equal(proof.overflow, false, 'No horizontal overflow expected at tablet/phone widths');
      outcomes.push({ viewport: viewport.name, status: 'PASS', categories: 19, mockCalls: proof.mockCalls, firebaseSdkLoaded: proof.firebaseSdkLoaded, externalRequests: externalRequests.length, horizontalOverflow: proof.overflow });
      await page.close();
    }
    console.log(JSON.stringify({ browser: 'Playwright Chromium on GitHub Actions', fixture: 'actual 9A modules from work/index.html + synthetic products; CSP connect-src none', outcomes, firebaseProductionWrites: 0 }, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
