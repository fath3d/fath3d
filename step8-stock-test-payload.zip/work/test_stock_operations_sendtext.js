const fs=require('node:fs');
const vm=require('node:vm');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');

const source=fs.readFileSync('work/index.html','utf8');
function script(id){const m=source.match(new RegExp(`<script id="${id}">([\\s\\S]*?)<\\/script>`));assert.ok(m,`script absent: ${id}`);return m[1];}
class E{constructor(id=''){this.id=id;this.hidden=false;this.children=[];this.listeners={};this.value='';this.disabled=false;this.style={};this.className='';this.scrollTop=0;this.scrollHeight=0;}addEventListener(t,f){this.listeners[t]=f;}append(...x){this.children.push(...x);this.scrollHeight=this.children.length;}appendChild(x){this.children.push(x);return x;}setAttribute(){}remove(){}focus(){}set textContent(v){this._text=String(v);this.children=[];}get textContent(){return this._text||'';}}
const ids=['jarvis-text-open','jarvis-text-backdrop','jarvis-text-panel','jarvis-text-close','jarvis-text-reset','jarvis-text-messages','jarvis-text-status','jarvis-text-form','jarvis-text-input','jarvis-text-send'];
const elements=Object.fromEntries(ids.map(id=>[id,new E(id)]));
const db={products:[
  {id:1001,name:'TORTUES',categorie:'Figurine',stocks:{maison:7,marche:2}},
  {id:1002,name:'PIKACHU',categorie:'HueForge',stocks:{maison:3,marche:4}},
  {id:1003,name:'MODELE 3',categorie:'HueForge',stocks:{maison:5,marche:0}},
  {id:1004,name:'PIKACHU MINI',categorie:'HueForge',stocks:{maison:1,marche:0}}
],sales:[{id:'sale-demo',total:12}],caisseHistory:[],ventesMarche:[]};
const document={body:new E('body'),getElementById:id=>elements[id]||null,createElement:()=>new E(),createTextNode:v=>({textContent:String(v)})};
let gatewayCalls=0,previewCalls=[],commitCalls=0,cancelCalls=0,failCommit=false;
const gateway={getState:()=>({writesEnabled:false,persistentConversation:false,firebaseDirectAccess:false}),send:async()=>{gatewayCalls++;return {answer:'gateway inattendu',proposal:null,meta:{writesEnabled:false,outcome:'direct_answer'}};}};
const window={document,navigator:{onLine:true},crypto:crypto.webcrypto,setInterval(){return 1;},setTimeout,clearTimeout,addEventListener(){},JarvisGateway:gateway,db};window.window=window;
window.prepareIndividualStockTransfer=async args=>{
  previewCalls.push({kind:'transfer',...args});const product=db.products.find(row=>String(row.id)===String(args.productId));
  if(!product||product.stocks[args.source]<args.quantity)return {ok:false,anomalies:[{code:'INSUFFICIENT_STOCK',message:'Stock source insuffisant.'}]};
  const maisonAfter=args.source==='maison'?product.stocks.maison-args.quantity:product.stocks.maison+args.quantity;
  const marcheAfter=args.source==='marche'?product.stocks.marche-args.quantity:product.stocks.marche+args.quantity;
  return {ok:true,noOp:false,operation:'individual_transfer',proposalId:'proposal-'+previewCalls.length,revision:12,items:[{id:product.id,name:product.name,quantity:args.quantity,maisonBefore:product.stocks.maison,marcheBefore:product.stocks.marche,homeAfter:maisonAfter,marketAfter:marcheAfter}]};
};
window.prepareSinglePhysicalStockCount=async args=>{
  previewCalls.push({kind:'count',...args});const product=db.products.find(row=>String(row.id)===String(args.productId));
  if(!product)return {ok:false,anomalies:[{code:'PRODUCT_NOT_FOUND',message:'Produit inconnu.'}]};
  return {ok:true,noOp:product.stocks[args.location]===args.quantity,operation:'physical_count',proposalId:'proposal-'+previewCalls.length,revision:12,items:[{id:product.id,name:product.name,maisonBefore:product.stocks.maison,marcheBefore:product.stocks.marche,homeAfter:args.location==='maison'?args.quantity:product.stocks.maison,marketAfter:args.location==='marche'?args.quantity:product.stocks.marche}]};
};
window.commitVersionedStockOperation=async(proposalId,options)=>{
  commitCalls++;assert.equal(options.explicit,true);if(failCommit)throw Object.assign(new Error('network uncertain'),{code:'unavailable'});
  const call=previewCalls.at(-1),product=db.products.find(row=>String(row.id)===String(call.productId));
  const homeAfter=call.kind==='count'?(call.location==='maison'?call.quantity:product.stocks.maison):(call.source==='maison'?product.stocks.maison-call.quantity:product.stocks.maison+call.quantity);
  const marketAfter=call.kind==='count'?(call.location==='marche'?call.quantity:product.stocks.marche):(call.source==='marche'?product.stocks.marche-call.quantity:product.stocks.marche+call.quantity);
  return {status:'executed',writePerformed:true,revision:13,operation:call.kind==='count'?'physical_count':'individual_transfer',pieces:call.quantity,items:[{id:product.id,name:product.name,homeAfter,marketAfter}]};
};
window.abortVersionedStockOperation=(id,options)=>{assert.equal(options.explicit,true);cancelCalls++;return {status:'cancelled',writePerformed:false};};
window.managerVersionedWritesEnabled=()=>false;
const context=vm.createContext({window,document,navigator:window.navigator,crypto:window.crypto,setInterval:window.setInterval,setTimeout,clearTimeout,Uint8Array,Date,JSON,Object,Array,Set,Map,String,Error,Promise,console,db});
for(const id of ['jarvis-security-step2','jarvis-write-broker-step6','jarvis-consultation-step5a','jarvis-replenishment-9a','jarvis-replenishment-9a3','jarvis-consultation-step5b','jarvis-consultation-step5c','jarvis-text-step4','jarvis-inventory8-step8a1'])vm.runInContext(script(id),context,{filename:id});
const api=window.JarvisConversation;assert.ok(api);const results=[];
async function test(name,fn){try{await fn();results.push({name,status:'RÉUSSI'});}catch(error){results.push({name,status:'ÉCHEC',message:error.message});}}
async function send(text){return api.sendText(text);}

(async()=>{
  api.reset();window.JarvisInventory8.reset();
  await test('Voix : transfert Maison → Marché, quantité en lettres, confirmation explicite',async()=>{
    previewCalls=[];commitCalls=0;const before=db.products[0].stocks.maison+db.products[0].stocks.marche;const preview=await send('Jarvis, transfère trois tortues de Maison vers Marché.');
    assert.equal(preview.outcome,'action_proposal');assert.match(preview.answer,/Le total reste inchangé/);assert.equal(previewCalls[0].quantity,3);assert.equal(previewCalls[0].source,'maison');assert.equal(previewCalls[0].destination,'marche');assert.equal(db.products[0].stocks.maison+db.products[0].stocks.marche,before);
    const done=await send('confirme');assert.match(done.answer,/Transfert enregistré/);assert.equal(commitCalls,1);assert.equal(db.products[0].stocks.maison,4);assert.equal(db.products[0].stocks.marche,5);
  });
  await test('Voix : transfert Marché → Maison, confirmation annulable sans commit',async()=>{
    previewCalls=[];commitCalls=0;cancelCalls=0;const before=db.products[1].stocks.maison+db.products[1].stocks.marche;const preview=await send('Jarvis, remets deux Pikachu du Marché à la Maison.');assert.equal(preview.outcome,'action_proposal');assert.equal(previewCalls[0].source,'marche');assert.equal(previewCalls[0].destination,'maison');const cancelled=await send('annule');assert.match(cancelled.answer,/annulée/);assert.equal(commitCalls,0);assert.equal(cancelCalls,1);assert.equal(db.products[1].stocks.maison+db.products[1].stocks.marche,before);
  });
  await test('Voix : pointage Maison sans le confondre avec un transfert',async()=>{
    previewCalls=[];const result=await send("Jarvis, j'ai compté six Pikachu à la maison.");assert.equal(result.outcome,'action_proposal');assert.deepEqual(previewCalls.at(-1),{kind:'count',productId:1002,location:'maison',quantity:6});assert.match(result.answer,/pas un transfert/);await send('annule');
  });
  await test('Voix : pointage Marché avec la quantité après « il me reste »',async()=>{
    previewCalls=[];const result=await send('Jarvis, il me reste deux tortues sur le stock Marché.');assert.equal(result.outcome,'action_proposal');assert.deepEqual(previewCalls.at(-1),{kind:'count',productId:1001,location:'marche',quantity:2});await send('annule');
  });
  await test('Nom produit avec chiffre préservé après quantité vocale',async()=>{
    previewCalls=[];const result=await send('Jarvis, transfère deux modèle 3 de Maison vers Marché.');assert.equal(result.outcome,'action_proposal');assert.equal(previewCalls.at(-1).productId,1003);assert.equal(previewCalls.at(-1).quantity,2);await send('annule');
  });
  await test('Quantité composée non reconnue demande clarification au lieu de deviner',async()=>{
    previewCalls=[];const result=await send('Jarvis, transfère vingt et deux tortues de Maison vers Marché.');assert.equal(result.outcome,'clarification');assert.match(result.answer,/quantité entière explicite/);assert.equal(previewCalls.length,0);
  });
  await test('Stock source insuffisant bloque la proposition et ne commit pas',async()=>{
    previewCalls=[];commitCalls=0;const result=await send('Jarvis, transfère huit tortues de Maison vers Marché.');assert.equal(result.outcome,'refusal');assert.match(result.answer,/insuffisant/);assert.equal(api.getSession().pendingStockOperation,null);assert.equal(commitCalls,0);
  });
  await test('Produit ambigu demande un choix et ne prépare rien avant clarification',async()=>{
    previewCalls=[];db.products.push({id:1005,name:'PIKACHU',categorie:'HueForge',stocks:{maison:1,marche:0}});const result=await send('Jarvis, transfère un Pikachu de Maison vers Marché.');assert.equal(result.outcome,'clarification');assert.match(result.answer,/Plusieurs produits correspondent/);assert.equal(previewCalls.length,0);const chosen=await send('le premier');assert.equal(chosen.outcome,'action_proposal');assert.equal(previewCalls.at(-1).productId,1002);assert.equal(previewCalls.at(-1).quantity,1);await send('annule');db.products.pop();
  });
  await test('Résultat réseau incertain : aucun succès annoncé ni seconde tentative',async()=>{
    previewCalls=[];commitCalls=0;failCommit=true;const prepared=await send('Jarvis, transfère un modèle 3 de Maison vers Marché.');assert.equal(prepared.outcome,'action_proposal',prepared.answer);const result=await send('confirme');assert.equal(result.outcome,'refusal');assert.match(result.answer,/aucune réussite n’est annoncée/i);assert.equal(commitCalls,1);assert.equal(api.getSession().pendingStockOperation,null);failCommit=false;
  });
  await test('Inventory8 conserve la priorité sur ses propres commandes',async()=>{
    window.JarvisInventory8.reset();previewCalls=[];await send('inventaire maison');await send('HueForge');const result=await send('transfère trois tortues de Maison vers Marché');assert.equal(previewCalls.length,0);assert.equal(window.JarvisInventory8.getState().active,true);window.JarvisInventory8.reset();
  });
  assert.equal(gatewayCalls,0);assert.equal(db.sales[0].total,12);assert.deepEqual(db.caisseHistory,[]);assert.deepEqual(db.ventesMarche,[]);
  const report={total:results.length,passed:results.filter(item=>item.status==='RÉUSSI').length,failed:results.filter(item=>item.status==='ÉCHEC').length,results,realFirebaseWrites:0,productionGate:false,gatewayCalls};
  console.log(JSON.stringify(report,null,2));if(report.failed)process.exitCode=1;
})();
