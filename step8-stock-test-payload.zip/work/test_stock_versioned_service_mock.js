const assert=require('node:assert/strict');
const {createMarketToHomeTransferService}=require('./manager-versioned-persistence.mjs');
const clone=value=>JSON.parse(JSON.stringify(value));
const initial={products:[
  {id:21,name:'TORTUE',stocks:{maison:7,marche:2}},
  {id:22,name:'PIKACHU',stocks:{maison:3,marche:4}},
  {id:23,name:'MODELE 3',stocks:{maison:5,marche:0}}
],sales:[{id:'demo-sale',total:42}],caisseHistory:[{ticket:'demo-ticket'}],ventesMarche:[{total:17}],settings:{stockMinDefaut:3}};
function persistence(seed=initial,revision=1,options={}){
  const state={exists:true,revisionInitialized:true,revision,data:clone(seed)};let saves=0,loadCalls=0;
  return {state,getSaves:()=>saves,getLoads:()=>loadCalls,api:{load:async()=>{loadCalls++;if(options.loadGate)await options.loadGate;return clone(state);},save:async(next,{expectedRevision}={})=>{
    saves++;if(options.saveGate)await options.saveGate;if(options.failSave)throw Object.assign(new Error(options.failSave),{code:options.failSave});
    if(!state.exists||state.revision!==expectedRevision)throw new Error('MANAGER_REVISION_CONFLICT');state.data=clone(next);state.revision++;return {ok:true,skipped:false,revision:state.revision};
  }}};
}
const create=(api,enabled=()=>true,now=()=>1000)=>createMarketToHomeTransferService({persistence:api,isWriteEnabled:enabled,now,createId:(()=>{let id=0;return()=>`proposal-${++id}`;})()});
const tests=[];async function test(name,fn){try{await fn();tests.push({name,status:'RÉUSSI'});}catch(error){tests.push({name,status:'ÉCHEC',message:error.message});}}

(async()=>{
  await test('Aperçu global Marché → Maison toujours présent et total inchangé',async()=>{
    const db=persistence(),service=create(db.api),preview=await service.preview();assert.equal(preview.references,2);assert.equal(preview.pieces,6);const done=await service.confirm(preview.proposalId,{explicit:true});assert.equal(done.status,'executed');assert.equal(db.state.data.products[0].stocks.maison,9);assert.equal(db.state.data.products[0].stocks.marche,0);assert.equal(db.state.data.products[0].stocks.maison+db.state.data.products[0].stocks.marche,9);
  });
  await test('Transfert individuel Maison → Marché, confirmation explicite et total constant',async()=>{
    const db=persistence(),service=create(db.api),preview=await service.previewTransfer({productId:21,quantity:3,source:'maison',destination:'marche'});assert.equal(preview.items[0].maisonAfter,4);assert.equal(preview.items[0].marcheAfter,5);await assert.rejects(()=>service.confirm(preview.proposalId),/EXPLICIT_CONFIRMATION_REQUIRED/);assert.equal(db.getSaves(),0);const done=await service.confirm(preview.proposalId,{explicit:true});assert.equal(done.writePerformed,true);assert.equal(db.state.data.products[0].stocks.maison+db.state.data.products[0].stocks.marche,9);
  });
  await test('Transfert individuel Marché → Maison et blocage quantité insuffisante',async()=>{
    const db=persistence(),service=create(db.api),preview=await service.previewTransfer({productId:22,quantity:2,source:'marche',destination:'maison'});assert.equal(preview.items[0].maisonAfter,5);assert.equal(preview.items[0].marcheAfter,2);const done=await service.confirm(preview.proposalId,{explicit:true});assert.equal(done.status,'executed');assert.equal(db.state.data.products[1].stocks.maison+db.state.data.products[1].stocks.marche,7);
    const before=db.getSaves(),blocked=await service.previewTransfer({productId:22,quantity:99,source:'marche',destination:'maison'});assert.equal(blocked.ok,false);assert.equal(blocked.anomalies[0].code,'INSUFFICIENT_STOCK');assert.equal(db.getSaves(),before);
  });
  await test('Pointage vocal Maison, sans écraser Marché',async()=>{
    const db=persistence(),service=create(db.api),preview=await service.previewCount({productId:21,location:'maison',quantity:6});assert.equal(preview.items[0].homeAfter,6);assert.equal(preview.items[0].marketAfter,2);const result=await service.confirm(preview.proposalId,{explicit:true});assert.equal(result.operation,'physical_count');assert.equal(db.state.data.products[0].stocks.maison,6);assert.equal(db.state.data.products[0].stocks.marche,2);
  });
  await test('Pointage vocal Marché accepte zéro sans le transformer en transfert',async()=>{
    const db=persistence(),service=create(db.api),preview=await service.previewCount({productId:22,location:'marche',quantity:0});assert.equal(preview.items[0].homeAfter,3);assert.equal(preview.items[0].marketAfter,0);await service.confirm(preview.proposalId,{explicit:true});assert.equal(db.state.data.products[1].stocks.maison,3);assert.equal(db.state.data.products[1].stocks.marche,0);
  });
  await test('Pointage manuel Maison + Marché en une proposition atomique et annulation',async()=>{
    const db=persistence(),service=create(db.api),preview=await service.previewCounts({productId:21,maison:1,marche:0});assert.equal(preview.items[0].totalAfter,1);assert.equal(service.cancel(preview.proposalId,{explicit:true}).writePerformed,false);assert.equal(db.getSaves(),0);assert.equal(db.state.revision,1);await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_PROPOSAL_INVALID/);
  });
  await test('Aucun changement ou total invalide ne produit de proposition',async()=>{
    const db=persistence(),service=create(db.api);assert.equal((await service.previewCount({productId:21,location:'maison',quantity:7})).noOp,true);await assert.rejects(()=>service.previewTransfer({productId:21,quantity:1,source:'maison',destination:'maison'}),/TRANSFER_DIRECTION_INVALID/);await assert.rejects(()=>service.previewTransfer({productId:21,quantity:0,source:'maison',destination:'marche'}),/TRANSFER_QUANTITY_INVALID/);assert.equal((await service.previewCounts({productId:21,maison:Number.MAX_SAFE_INTEGER,marche:1})).ok,false);assert.equal(db.getSaves(),0);
  });
  await test('Révision modifiée après aperçu bloque le commit et protège la nouvelle donnée',async()=>{
    const db=persistence(),service=create(db.api),preview=await service.previewTransfer({productId:21,quantity:1,source:'maison',destination:'marche'});db.state.revision=2;db.state.data.products[0].stocks.maison=99;await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/MANAGER_REVISION_CONFLICT/);assert.equal(db.state.data.products[0].stocks.maison,99);assert.equal(db.getSaves(),0);
  });
  await test('Double confirmation simultanée : une seule exécution',async()=>{
    let release,block=false;const gate=new Promise(resolve=>release=resolve),db=persistence(),api={...db.api,load:async()=>{if(block)await gate;return db.api.load();}},service=create(api),preview=await service.preview();block=true;const first=service.confirm(preview.proposalId,{explicit:true});await new Promise(resolve=>setImmediate(resolve));await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_EXECUTION_IN_PROGRESS/);release();assert.equal((await first).status,'executed');assert.equal(db.getSaves(),1);
  });
  await test('Erreur réseau: un seul essai, résultat non confirmé, aucun rejeu',async()=>{
    const db=persistence(initial,1,{failSave:'unavailable'}),service=create(db.api),preview=await service.previewCount({productId:21,location:'maison',quantity:0});await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/unavailable/);assert.equal(db.getSaves(),1);await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/TRANSFER_PROPOSAL_INVALID/);assert.equal(db.getSaves(),1);assert.equal(db.state.revision,1);
  });
  await test('Verrou de production fermé : aperçu permis, confirmation sans save',async()=>{
    const db=persistence(),service=create(db.api,()=>false),preview=await service.previewTransfer({productId:21,quantity:1,source:'maison',destination:'marche'});await assert.rejects(()=>service.confirm(preview.proposalId,{explicit:true}),/MANAGER_VERSIONED_WRITES_DISABLED/);assert.equal(db.getSaves(),0);assert.equal(db.state.revision,1);
  });
  await test('Stocks hors opération, ventes, caisse et règles 9A conservés',async()=>{
    const db=persistence(),service=create(db.api),before=clone(db.state.data),preview=await service.previewTransfer({productId:22,quantity:1,source:'marche',destination:'maison'});await service.confirm(preview.proposalId,{explicit:true});assert.deepEqual(db.state.data.sales,before.sales);assert.deepEqual(db.state.data.caisseHistory,before.caisseHistory);assert.deepEqual(db.state.data.ventesMarche,before.ventesMarche);assert.deepEqual(db.state.data.settings,before.settings);assert.equal(db.state.data.products[0].stocks.maison,before.products[0].stocks.maison);assert.equal(db.state.data.products[0].stocks.marche,before.products[0].stocks.marche);
  });
  const report={total:tests.length,passed:tests.filter(item=>item.status==='RÉUSSI').length,failed:tests.filter(item=>item.status==='ÉCHEC').length,tests,mode:'MOCK versioned persistence; not Firestore Emulator',realFirebaseWrites:0,productionGate:false};
  console.log(JSON.stringify(report,null,2));if(report.failed)process.exitCode=1;
})();
