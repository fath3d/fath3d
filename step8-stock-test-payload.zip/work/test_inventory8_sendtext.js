const fs=require('node:fs');
const vm=require('node:vm');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');

const source=fs.readFileSync('work/index.html','utf8');
function script(id){const m=source.match(new RegExp(`<script id="${id}">([\\s\\S]*?)<\\/script>`));assert.ok(m,`script absent: ${id}`);return m[1];}
class E{constructor(id=''){this.id=id;this.hidden=false;this.children=[];this.listeners={};this.value='';this.disabled=false;this.style={};}addEventListener(t,f){this.listeners[t]=f;}append(...x){this.children.push(...x);}appendChild(x){this.children.push(x);return x;}setAttribute(){}remove(){}focus(){}set textContent(v){this._text=String(v);this.children=[];}get textContent(){return this._text||'';}}
const ids=['jarvis-text-open','jarvis-text-backdrop','jarvis-text-panel','jarvis-text-close','jarvis-text-reset','jarvis-text-messages','jarvis-text-status','jarvis-text-form','jarvis-text-input','jarvis-text-send'];
const elements=Object.fromEntries(ids.map(id=>[id,new E(id)]));
const db={sales:[],products:[
  {id:217,name:'STITCH ANGE',categorie:'HueForge',stocks:{maison:3}},
  {id:302,name:'GOHAN BEAST',categorie:'HueForge',stocks:{maison:2}},
  {id:303,name:'GOHAN SSJ2',categorie:'HueForge',stocks:{maison:2}},
  {id:301,name:'GOKU GENKIDAMA',categorie:'HueForge',stocks:{maison:2}},
  {id:501,name:'PIKACHU',categorie:'HueForge',stocks:{maison:2}},
  {id:502,name:'MODELE 3',categorie:'HueForge',stocks:{maison:1}},
  {id:103,name:'ZORO',categorie:'HueForge',stocks:{maison:1,marche:1}}
]};
const document={body:new E('body'),getElementById:id=>elements[id]||null,createElement:()=>new E(),createTextNode:v=>({textContent:String(v)})};
const window={document,navigator:{onLine:true},crypto:crypto.webcrypto,setInterval(){return 1;},setTimeout,clearTimeout,addEventListener(){},db}; window.window=window;
const context=vm.createContext({window,document,navigator:window.navigator,crypto:window.crypto,setInterval:window.setInterval,setTimeout,clearTimeout,Uint8Array,Date,JSON,Object,Array,Set,Map,String,Error,Promise,console,db});
for(const id of ['jarvis-security-step2','jarvis-write-broker-step6','jarvis-consultation-step5a','jarvis-consultation-step5b','jarvis-consultation-step5c']) vm.runInContext(script(id),context,{filename:id});
window.JarvisGateway={getState:()=>({writesEnabled:false,persistentConversation:false,firebaseDirectAccess:false}),send:async()=>({answer:'gateway inattendu',proposal:null,meta:{writesEnabled:false,outcome:'direct_answer'}})};
vm.runInContext(script('jarvis-text-step4'),context,{filename:'jarvis-text-step4'});
window.JarvisVoice7={normalizeVoiceBusinessTerms(v){return String(v).replace(/\b(?:hue\s*forge|you\s*forge|youforge|u\s*forge)\b/ig,'HueForge');}};
vm.runInContext(script('jarvis-inventory8-step8a1'),context,{filename:'jarvis-inventory8-step8a1'});
const api=window.JarvisConversation; assert.ok(api);
async function send(v){return api.sendText(v);}
(async()=>{
  const answers=[]; api.reset(); window.JarvisInventory8.reset();
  for(const start of ['inventaire','faire l inventaire','on fait l inventaire','on va faire l inventaire','commence l inventaire','Jarvis inventaire']){
    window.JarvisInventory8.reset(); const r=await send(start); assert.match(r.answer,/Maison|emplacement/); answers.push(r.answer);
  }
  window.JarvisInventory8.reset(); let rMaison=await send('inventaire maison'); assert.match(rMaison.answer,/Quelle catégorie/); answers.push(rMaison.answer);
  window.JarvisInventory8.reset(); let rMarket=await send('inventaire marché'); assert.match(rMarket.answer,/limit. à Maison/); answers.push(rMarket.answer);
  window.JarvisInventory8.reset(); answers.push((await send('on fait l inventaire')).answer); answers.push((await send('Maison')).answer); 
  for(const variant of ['HueForge','hue forge','you forge','YouForge','u forge']){
    window.JarvisInventory8.reset(); await send('on fait l inventaire'); await send('Maison');
    const r=await send(variant); assert.match(r.answer,/Catégorie HueForge/); answers.push(r.answer);
  }
  window.JarvisInventory8.reset(); await send('on fait l inventaire'); await send('Maison'); await send('HueForge');
  for(const [text,expected] of [['Pikachu',1],['3 Pikachu',3],['Pikachu 3',3],['Pikachu x3',3],['Pikachu quantité 3',3],['quantité 3 Pikachu',3],['deux Pikachu',2],['Pikachu deux',2]]){
    window.JarvisInventory8.reset(); await send('on fait l inventaire'); await send('Maison'); await send('HueForge');
    const r=await send(text); assert.match(r.answer,new RegExp('^'+expected+' — PIKACHU')); answers.push(r.answer);
  }
  window.JarvisInventory8.reset(); await send('on fait l inventaire'); await send('Maison'); await send('HueForge');
  assert.match((await send('MODELE 3')).answer,/1 — MODELE 3/);
  assert.equal(db.products.find(p=>p.id===501).stocks.maison,2);
  window.JarvisInventory8.reset(); await send('inventaire maison'); assert.match((await send('HueForge')).answer,/Catégorie HueForge/);
  assert.match((await send('Pikachu 3')).answer,/^3 — PIKACHU/);
  assert.match((await send('inventaire terminé')).answer,/Inventaire terminé/);
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('Pikachu');
  assert.match((await send('Jarvis annule l inventaire')).answer,/Inventaire annulé/);
  assert.equal(window.JarvisInventory8.getState().stage,'OFF');
  assert.match((await send('inventaire maison')).answer,/Quelle catégorie/);
  window.JarvisInventory8.reset(); assert.match((await send('inventaire')).answer,/emplacement/);
  window.JarvisInventory8.reset(); assert.doesNotMatch((await send('ancien inventaire')).answer,/emplacement|Quelle catégorie/);
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge');
  let burst=(await send('Gohan Beast quantité 1, Gohan SSJ2 quantité 1, Goku Genkidama quantité 1')).answer; assert.equal(window.JarvisInventory8.getState().entries.length,3); assert.match(burst,/GOHAN BEAST/);
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('Pikachu 1, Pikachu 2'); assert.equal(window.JarvisInventory8.getState().entries[0].quantity,3);
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('Gohan Beast 1, produit bidon 1, Goku Genkidama 1'); assert.equal(window.JarvisInventory8.getState().entries.length,2);
  for(const name of ['PRODUIT ALPHA','PRODUIT BETA','PRODUIT GAMMA','PRODUIT DELTA','PRODUIT EPSILON','PRODUIT ZETA','PRODUIT ETA','PRODUIT THETA','PRODUIT IOTA','PRODUIT KAPPA']) db.products.push({id:900+db.products.length,name,categorie:'HueForge',stocks:{maison:1}});
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('PRODUIT ALPHA, PRODUIT BETA, PRODUIT GAMMA'); assert.equal(window.JarvisInventory8.getState().entries.length,3);
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('PRODUIT ALPHA, PRODUIT BETA, PRODUIT GAMMA, PRODUIT DELTA, PRODUIT EPSILON'); assert.equal(window.JarvisInventory8.getState().entries.length,5);
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('PRODUIT ALPHA, PRODUIT BETA, PRODUIT GAMMA, PRODUIT DELTA, PRODUIT EPSILON, PRODUIT ZETA, PRODUIT ETA, PRODUIT THETA, PRODUIT IOTA, PRODUIT KAPPA'); assert.equal(window.JarvisInventory8.getState().entries.length,10);
  // 8C : comparaison lecture seule via le vrai sendText().
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge');
  await send('STITCH ANGE 1, GOHAN BEAST 1, GOHAN SSJ2 1');
  const beforeStocks=JSON.stringify(db.products.map(p=>p.stocks));
  let comparisonResult=await send('inventaire terminé');
  let comparison=window.JarvisInventory8.getComparison();
  assert.equal(comparison.rows.length,3); assert.equal(comparison.rows.find(r=>r.productId===217).delta,-2); // stock 3 / compté 1
  assert.equal(comparison.rows.find(r=>r.productId===302).delta,-1); // stock 2 / compté 1
  assert.equal(comparison.rows.find(r=>r.productId===303).delta,-1); // stock 2 / compté 1
  assert.match(comparisonResult.answer,/Comparatif lecture seule/); assert.equal(JSON.stringify(db.products.map(p=>p.stocks)),beforeStocks);
  // stock zéro, égalité et stock inconnu sont distingués explicitement.
  db.products.push({id:7001,name:'ZERO TEST',categorie:'HueForge',stocks:{maison:0}},{id:7002,name:'UNKNOWN TEST',categorie:'HueForge',stocks:{}});
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('ZERO TEST 1, UNKNOWN TEST 1'); await send('inventaire terminé'); comparison=window.JarvisInventory8.getComparison();
  assert.equal(comparison.rows.find(r=>r.productId===7001).delta,1); const unknown=comparison.rows.find(r=>r.productId===7002); assert.equal(unknown.stockKnown,false); assert.equal(unknown.delta,null);
  // Non-compté absent du snapshot, ligne annulée exclue, validée incluse.
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('PIKACHU 1, MODELE 3 1');
  window.JarvisInventory8.manualLineAction(1,'cancel'); window.JarvisInventory8.manualLineAction(0,'validate'); await send('inventaire terminé'); comparison=window.JarvisInventory8.getComparison(); assert.deepEqual(comparison.rows.map(r=>r.productId),[501]);
  // Fin répétée : le snapshot reste unique et stable.
  const snapshotAtFinish=JSON.stringify(window.JarvisInventory8.getState().snapshot); await send('inventaire terminé'); assert.equal(JSON.stringify(window.JarvisInventory8.getState().snapshot),snapshotAtFinish);
  // 8D : proposition globale puis orchestration mockée, sans Firebase réel.
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('PIKACHU 1'); await send('inventaire terminé');
  let finalProposal=window.JarvisInventory8.getFinalProposal(); assert.equal(finalProposal.proposals.length,1); assert.equal(finalProposal.proposals[0].expectedBefore,2);
  let mockCalls=0; window.JarvisSecurity.verifyRuntimeBackupRestore(db); window.jarvisScopedStockAdjustCommit=async request=>{mockCalls++;assert.equal(request.scopedAuthorization.location,'maison');return {firebaseWritePerformed:false,neutralized:true};};
  let dry=await window.JarvisInventory8.validateFinal(db,{explicit:true}); assert.equal(dry.writes,0); assert.equal(mockCalls,0);
  // nouvelle session pour la validation globale simulée complète.
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); await send('PIKACHU 1'); await send('inventaire terminé');
  const executed=await window.JarvisInventory8.validateFinal(db,{explicit:true,dryRun:false}); assert.equal(executed.ok,true); assert.equal(mockCalls,1); assert.equal(db.products.find(p=>p.id===501).stocks.maison,2);
  // Multi-séries 8D : une session catégorie, plusieurs lots, aucun héritage.
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); const sessionA=window.JarvisInventory8.getState().sessionId;
  await send('PIKACHU 1, MODELE 3 1, GOKU GENKIDAMA 1'); await send('valider la série'); let multi=window.JarvisInventory8.getState(); assert.equal(multi.active,true); assert.equal(multi.batches.length,2); assert.equal(multi.entries.length,0);
  await send('STITCH ANGE 1, GOHAN BEAST 1, GOHAN SSJ2 1'); window.JarvisInventory8.manualLineAction(1,'cancel'); await send('valider la série'); await send('inventaire terminé');
  let globalSnapshot=window.JarvisInventory8.getState().snapshot; assert.equal(globalSnapshot.entries.length,5); assert.equal(globalSnapshot.entries.some(e=>e.name==='GOHAN BEAST'),false);
  window.JarvisInventory8.reset(); await send('inventaire maison'); await send('HueForge'); const sessionB=window.JarvisInventory8.getState().sessionId; assert.notEqual(sessionA,sessionB); await send('PIKACHU 1'); await send('inventaire terminé'); assert.equal(window.JarvisInventory8.getState().snapshot.entries.length,1);
  console.log('INVENTORY8_8D_MOCK_OK',JSON.stringify({oneProposal:true,globalValidation:true,dryRunCalls:0,mockCalls:1,realWrites:0}));
  console.log('INVENTORY8_8C_OK',JSON.stringify({tests:10,writes:0,nonCountedNotZero:true,unknownDistinct:true,snapshotStable:true}));
  console.log('INVENTORY8_SENDTEXT_OK',JSON.stringify({cases:34,writes:0,answers:answers.length}));
})().catch(e=>{console.error(e.stack||e);process.exitCode=1;});
