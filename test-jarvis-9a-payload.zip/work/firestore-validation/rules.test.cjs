const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {initializeTestEnvironment,assertFails,assertSucceeds}=require('@firebase/rules-unit-testing');
const {doc,collection,getDoc,getDocs,setDoc,deleteDoc,writeBatch,runTransaction,setLogLevel}=require('firebase/firestore');
const PROJECT='demo-jarvis-rules-validation',HOST='127.0.0.1',PORT=8785,UID='owner-test',OTHER='other-test';
if(process.env.FIRESTORE_EMULATOR_HOST!==HOST+':'+PORT)throw new Error('ISOLATION_REQUIRED: explicit local emulator host missing');
if(process.env.GCLOUD_PROJECT!==PROJECT||!PROJECT.startsWith('demo-'))throw new Error('ISOLATION_REQUIRED: synthetic demo project only');
setLogLevel('silent');
const rulesPath=path.resolve(__dirname,'../firestore.rules.proposed'),appPath=path.resolve(__dirname,'../index.html');
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const appBefore=hash(appPath),rulesBefore=hash(rulesPath),results=[];let env,owner,other,anonymous;
assert.equal(hash(path.join(__dirname,'rules-under-test.rules')),rulesBefore,'Staged Rules must equal proposed source exactly');
const root=uid=>'fath3d/'+uid+'/settings/replenishment';
const rootRef=(db=owner,uid=UID)=>doc(db,root(uid));
const exceptionRef=(id='103',db=owner,uid=UID)=>doc(db,root(uid)+'/exceptions/'+id);
const entry=(value=2,scope='maison_marche')=>({value,scope});
const config=(revision=1,categoryRules={},marker='mutation-test-revision-'+revision)=>({schemaVersion:1,revision,categoryRules,lastMutationId:marker});
const exception=(revision=2,rule={targetStock:entry(4)},id='103')=>({schemaVersion:1,productId:id,parentRevision:revision,rule});
async function seed(rootData=config(),exceptionData=null){await env.withSecurityRulesDisabled(async context=>{const db=context.firestore();await setDoc(rootRef(db),rootData);if(exceptionData)await setDoc(exceptionRef('103',db),exceptionData);});}
async function test(name,fn){const start=performance.now();try{await env.clearFirestore();await fn();results.push({name,status:'RÉUSSI',durationMs:Math.round(performance.now()-start)});}catch(error){results.push({name,status:'ÉCHEC',error:error.message,durationMs:Math.round(performance.now()-start)});}}
function batchException(parent=config(2),child=exception(),id='103') {const batch=writeBatch(owner);batch.set(rootRef(),parent);batch.set(exceptionRef(id),child);return batch;}
const categories=['autre','boucle d oreilles','coloriage','destockage','fete pere','figurine','fin d annee','flexible','halloween','hueforge','lampes','marque page','minimaux','panier 3e','panier 4','panier 5','panier 6','panier mini dragon 3','porte clefs'];
(async()=>{
  try{
    env=await initializeTestEnvironment({projectId:PROJECT,firestore:{host:HOST,port:PORT,rules:fs.readFileSync(rulesPath,'utf8')}});
    results.push({name:'Compilation du fichier Rules complet dans Firestore Emulator',status:'RÉUSSI'});
    owner=env.authenticatedContext(UID).firestore();other=env.authenticatedContext(OTHER).firestore();anonymous=env.unauthenticatedContext().firestore();
    await test('A propriétaire : lecture document dédié autorisée',async()=>{await seed();assert((await assertSucceeds(getDoc(rootRef()))).exists());});
    await test('B non authentifié : lecture refusée',async()=>{await seed();await assertFails(getDoc(rootRef(anonymous)));});
    await test('B non authentifié : création et mise à jour refusées',async()=>{await assertFails(setDoc(rootRef(anonymous),config()));await seed();await assertFails(setDoc(rootRef(anonymous),config(2)));});
    await test('C autre UID : lecture et écriture refusées',async()=>{await seed();await assertFails(getDoc(rootRef(other)));await assertFails(setDoc(rootRef(other),config(2)));});
    await test('D propriétaire : création règle valide acceptée',async()=>{await assertSucceeds(setDoc(rootRef(),config(1,{hueforge:{targetStock:entry(2)}})));});
    await test('D modification valide et révision +1 acceptées',async()=>{await seed();await assertSucceeds(setDoc(rootRef(),config(2,{hueforge:{targetStock:entry(2)}})));assert.equal((await getDoc(rootRef())).data().revision,2);});
    await test('D vraie transaction locale avec contrôle expectedRevision',async()=>{await seed();await assertSucceeds(runTransaction(owner,async transaction=>{const current=await transaction.get(rootRef());assert.equal(current.data().revision,1);transaction.set(rootRef(),config(2,{hueforge:{targetStock:entry(2)}}));}));});
    await test('E champ parent interdit refusé',async()=>{await assertFails(setDoc(rootRef(),{...config(),unknown:'forbidden'}));});
    await test('E champ imbriqué interdit refusé',async()=>{await assertFails(setDoc(rootRef(),config(1,{hueforge:{unknown:entry()}})));});
    await test('E propriété supplémentaire dans entrée refusée',async()=>{await assertFails(setDoc(rootRef(),config(1,{hueforge:{targetStock:{...entry(),extra:true}}})));});
    for(const [field,value] of [['schemaVersion','1'],['schemaVersion',1.5],['revision','1'],['revision',1.5],['categoryRules',[]],['lastMutationId',123]])await test('F mauvais type parent '+field+' = '+JSON.stringify(value),async()=>{await assertFails(setDoc(rootRef(),{...config(),[field]:value}));});
    for(const value of ['2',true,2.5,null,NaN,Infinity])await test('F mauvais type valeur '+String(value),async()=>{await assertFails(setDoc(rootRef(),config(1,{hueforge:{targetStock:entry(value)}})));});
    await test('F scope différent Maison + Marché refusé',async()=>{await assertFails(setDoc(rootRef(),config(1,{hueforge:{targetStock:entry(2,'maison')}})));});
    await test('F booléen exclusion et priorité int validés',async()=>{await assertSucceeds(setDoc(rootRef(),config(1,{hueforge:{excluded:true,abandoned:false,priority:1}})));});
    await test('F exclusion string et priorité float refusées',async()=>{await assertFails(setDoc(rootRef(),config(1,{hueforge:{excluded:'true'}})));await assertFails(setDoc(rootRef(),config(1,{hueforge:{priority:1.5}})));});
    await test('H catégorie inconnue refusée',async()=>{await assertFails(setDoc(rootRef(),config(1,{invented_category:{}})));});
    await test('H alias non canonique refusé comme clé serveur',async()=>{await assertFails(setDoc(rootRef(),config(1,{YouForge:{}})));});
    for(const category of categories)await test('G/I clé catégorie '+category+' autorisée, bloc vide sans nouvelle valeur métier',async()=>{await assertSucceeds(setDoc(rootRef(),config(1,{[category]:{}})));});
    await test('I les 19 catégories ensemble, aucune valeur métier nouvelle',async()=>{await assertSucceeds(setDoc(rootRef(),config(1,Object.fromEntries(categories.map(key=>[key,{}])))));});
    await test('I initialisation bulk dense refusée : une catégorie configurée par proposition',async()=>{const blocks=Object.fromEntries(categories.map(key=>[key,{targetStock:entry(7),alertThreshold:entry(6),replenishQuantity:entry(5)}]));await assertFails(setDoc(rootRef(),config(1,blocks)));});
    await test('I 19 catégories denses configurées progressivement, schéma complet conservé',async()=>{const blocks=Object.fromEntries(categories.map(key=>[key,{}]));await assertSucceeds(setDoc(rootRef(),config(1,blocks)));let revision=1;for(const key of categories){blocks[key]={targetStock:entry(7),alertThreshold:entry(6),replenishQuantity:entry(5)};await assertSucceeds(setDoc(rootRef(),config(++revision,blocks)));}assert.equal(Object.keys((await getDoc(rootRef())).data().categoryRules).length,19);assert.equal((await getDoc(rootRef())).data().revision,20);});
    await test('I update bulk de deux catégories refusé sans assouplir validation',async()=>{await seed();await assertFails(setDoc(rootRef(),config(2,{hueforge:{targetStock:entry()},figurine:{targetStock:entry()}})));});
    await test('I bloc corrompu lors d’un update de document dense refusé',async()=>{const blocks=Object.fromEntries(categories.map(key=>[key,{targetStock:entry(7),alertThreshold:entry(6),replenishQuantity:entry(5)}]));await seed(config(20,blocks));blocks.hueforge.targetStock={value:'forbidden',scope:'maison_marche'};await assertFails(setDoc(rootRef(),config(21,blocks)));});
    await test('I exception atomique avec parent dense 19 catégories acceptée',async()=>{const blocks=Object.fromEntries(categories.map(key=>[key,{targetStock:entry(7),alertThreshold:entry(6),replenishQuantity:entry(5)}]));await seed(config(20,blocks));await assertSucceeds(batchException(config(21,blocks),exception(21)).commit());});
    await test('J création avec révision 0 ou 2 refusée',async()=>{await assertFails(setDoc(rootRef(),config(0)));await assertFails(setDoc(rootRef(),config(2)));});
    await test('J révision inchangée et saut de révision refusés',async()=>{await seed();await assertFails(setDoc(rootRef(),config(1,{},'new-marker-unchanged')));await assertFails(setDoc(rootRef(),config(3)));});
    await test('J rejeu dernière mutation refusé malgré révision +1',async()=>{await seed();await assertFails(setDoc(rootRef(),config(2,{},'mutation-test-revision-1')));});
    await test('J proposition périmée après concurrent : seconde écriture refusée',async()=>{await seed();await assertSucceeds(setDoc(rootRef(),config(2,{},'first-concurrent-mutation')));await assertFails(setDoc(rootRef(),config(2,{},'second-concurrent-mutation')));assert.equal((await getDoc(rootRef())).data().lastMutationId,'first-concurrent-mutation');});
    await test('K exception créée atomiquement avec parent existant',async()=>{await seed();await assertSucceeds(batchException().commit());assert((await getDoc(exceptionRef())).exists());});
    await test('K première exception + création parent même batch',async()=>{await assertSucceeds(batchException(config(1),exception(1)).commit());});
    await test('K exception modifiée atomiquement, propriétaire lit et liste',async()=>{await seed(config(),exception(1));await assertSucceeds(batchException(config(2),exception(2,{targetStock:entry(5)})).commit());await assertSucceeds(getDoc(exceptionRef()));assert.equal((await assertSucceeds(getDocs(collection(owner,root(UID)+'/exceptions')))).size,1);});
    await test('K suppression exception atomique autorisée (retour héritage)',async()=>{await seed(config(),exception(1));const batch=writeBatch(owner);batch.set(rootRef(),config(2));batch.delete(exceptionRef());await assertSucceeds(batch.commit());assert.equal((await getDoc(exceptionRef())).exists(),false);});
    for(const [field,value] of [['productId','999'],['productId',103],['parentRevision',1],['parentRevision','2'],['parentRevision',2.5],['schemaVersion','1'],['schemaVersion',2],['rule',null],['rule',[]]])await test('L exception invalide '+field+' = '+JSON.stringify(value),async()=>{await seed();await assertFails(batchException(config(2),{...exception(),[field]:value}).commit());assert.equal((await getDoc(rootRef())).data().revision,1);});
    await test('L exception champ supplémentaire refusé',async()=>{await seed();await assertFails(batchException(config(2),{...exception(),unknown:true}).commit());});
    await test('L règle exception imbriquée non conforme refusée',async()=>{await seed();await assertFails(batchException(config(2),exception(2,{targetStock:{value:-1,scope:'maison_marche'}})).commit());});
    await test('B/C exception : autre UID et anonyme refusés en lecture',async()=>{await seed(config(),exception(1));await assertFails(getDoc(exceptionRef('103',other)));await assertFails(getDoc(exceptionRef('103',anonymous)));});
    await test('M création exception seule refusée même parentRevision égale parent',async()=>{await seed();await assertFails(setDoc(exceptionRef(),exception(1)));});
    await test('M modification exception seule refusée',async()=>{await seed(config(),exception(1));await assertFails(setDoc(exceptionRef(),exception(1,{targetStock:entry(5)})));});
    await test('M exception seule sans parent refusée',async()=>{await assertFails(setDoc(exceptionRef(),exception(1)));});
    await test('M parent non avancé dans batch : refus atomique',async()=>{await seed();await assertFails(batchException(config(1,{},'unchanged-parent-new-marker'),exception(1)).commit());});
    await test('M batch avec exception autre UID : tout est refusé',async()=>{await seed();const batch=writeBatch(owner);batch.set(rootRef(),config(2));batch.set(exceptionRef('103',owner,OTHER),exception());await assertFails(batch.commit());assert.equal((await getDoc(rootRef())).data().revision,1);});
    await test('N suppression parent dédiée refusée',async()=>{await seed();await assertFails(deleteDoc(rootRef()));});
    await test('N suppression exception seule refusée',async()=>{await seed(config(),exception(1));await assertFails(deleteDoc(exceptionRef()));});
    await test('O document principal : propriétaire garde lecture/écriture historique',async()=>{const main=doc(owner,'fath3d/'+UID);await assertSucceeds(setDoc(main,{payload:'fixture-only',updated:'test'}));assert.equal((await assertSucceeds(getDoc(main))).data().payload,'fixture-only');});
    await test('O suppression document principal par propriétaire inchangée (fixture seulement)',async()=>{const main=doc(owner,'fath3d/'+UID);await assertSucceeds(setDoc(main,{payload:'fixture-only'}));await assertSucceeds(deleteDoc(main));});
    await test('O document principal : autres UID/anonyme refusés',async()=>{await env.withSecurityRulesDisabled(async c=>setDoc(doc(c.firestore(),'fath3d/'+UID),{payload:'fixture-only'}));for(const db of [other,anonymous]){await assertFails(getDoc(doc(db,'fath3d/'+UID)));await assertFails(setDoc(doc(db,'fath3d/'+UID),{payload:'forbidden'}));}});
    for(const suffix of ['settings/other','settings/replenishment/history/entry','settings/replenishment/exceptions/103/history/entry','stocks/maison'])await test('O chemin supplémentaire '+suffix+' refusé',async()=>{await assertFails(setDoc(doc(owner,'fath3d/'+UID+'/'+suffix),{value:1}));await assertFails(getDoc(doc(owner,'fath3d/'+UID+'/'+suffix)));});
    for(const field of ['stocks','sales','ca','caisse','urssaf'])await test('P champ '+field+' interdit dans parent et règle imbriquée',async()=>{await assertFails(setDoc(rootRef(),{...config(),[field]:{value:1}}));await assertFails(setDoc(rootRef(),config(1,{hueforge:{[field]:1}})));});
    await test('P exception contient champ stock/finance : refus atomique',async()=>{await seed();await assertFails(batchException(config(2),exception(2,{stocks:{maison:2},sales:1})).commit());});
    for(const field of ['schemaVersion','revision','categoryRules','lastMutationId'])await test('Q champ requis '+field+' absent/null refusé',async()=>{const missing=config();delete missing[field];await assertFails(setDoc(rootRef(),missing));await assertFails(setDoc(rootRef(),{...config(),[field]:null}));});
    await test('Q entrée value ou scope absent : refus',async()=>{for(const value of [{scope:'maison_marche'},{value:2},null])await assertFails(setDoc(rootRef(),config(1,{hueforge:{targetStock:value}})));});
    await test('Q valeurs bornées 0 et 2147483647 acceptées',async()=>{await assertSucceeds(setDoc(rootRef(),config(1,{hueforge:{targetStock:entry(0),alertThreshold:entry(2147483647)}})));});
    await test('Q valeurs -1 et 2147483648 refusées',async()=>{for(const value of [-1,2147483648])await assertFails(setDoc(rootRef(),config(1,{hueforge:{targetStock:entry(value)}})));});
    await test('Q marker court/long refusé, bornes 16/80 acceptées',async()=>{for(const length of [0,15,81])await assertFails(setDoc(rootRef(),config(1,{},'a'.repeat(length))));await assertSucceeds(setDoc(rootRef(),config(1,{},'a'.repeat(16))));await assertSucceeds(setDoc(rootRef(),config(2,{},'a'.repeat(80))));});
    await test('Q categoryRules vide accepté sans valeurs par défaut côté serveur',async()=>{await assertSucceeds(setDoc(rootRef(),config()));assert.deepEqual((await getDoc(rootRef())).data().categoryRules,{});});
  }catch(error){results.push({name:'Initialisation / compilation obligatoire',status:'ÉCHEC',error:error.message});}
  finally{
    if(env)await env.cleanup();
    assert.equal(hash(appPath),appBefore,'work/index.html changed during rules-only mission');
    const report={projectId:PROJECT,emulator:HOST+':'+PORT,compiled:results.some(r=>r.name.startsWith('Compilation')&&r.status==='RÉUSSI'),total:results.length,passed:results.filter(r=>r.status==='RÉUSSI').length,failed:results.filter(r=>r.status==='ÉCHEC').length,firebaseProductionWrites:0,indexUnchanged:true,indexSHA256:appBefore,rulesSHA256:rulesBefore,results};
    fs.writeFileSync(path.join(__dirname,'results.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));if(report.failed)process.exitCode=1;
  }
})();
