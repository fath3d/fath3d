const fs=require('fs');
const vm=require('vm');
const crypto=require('crypto');

const sourcePath=process.argv[2]||'work/index.html';
const source=fs.readFileSync(sourcePath,'utf8');
function script(id){const match=source.match(new RegExp('<script id="'+id+'">([\\s\\S]*?)<\\/script>'));if(!match)throw new Error('Script introuvable : '+id);return match[1];}
const db={products:[
  {id:1,name:'LEVIATOR',categorie:'Hueforge',stocks:{maison:0,marche:1}},
  {id:2,name:'LEVIATOR',categorie:'Figurine',stocks:{maison:1,marche:1}},
  {id:3,name:'DRACAUFEU',categorie:'Figurine',stocks:{maison:2,marche:0}},
  {id:4,name:'DRACAUFEU',categorie:'Hueforge',stocks:{maison:0,marche:0}},
  {id:5,name:'PIKACHU',categorie:'Hueforge',stocks:{maison:0,marche:0}},
  {id:6,name:'MINI CHAT',categorie:'Minimaux',stocks:{maison:5,marche:0}},
  {id:7,name:'LAMA',categorie:'Minimaux',stocks:{maison:6,marche:0}},
  {id:8,name:'MARQUE PAGE OURS',categorie:'Marque Page',stocks:{maison:0,marche:0}},
  {id:9,name:'PORTE CLE OURS',categorie:'Porte clefs',stocks:{maison:0,marche:0}},
  {id:10,name:'LAMPE LUNE',categorie:'Lampes',stocks:{maison:0,marche:0}}
],stockAlertSeuil:3,stockMinDefaut:3,sales:[{id:1,total:10}],caisseHistory:[],ventesMarche:[]};
class FakeElement{
  constructor(id=''){this.id=id;this.hidden=['jarvis-text-panel','jarvis-text-backdrop'].includes(id);this.children=[];this.listeners={};this.value='';this.disabled=false;this.className='';this.scrollTop=0;this.scrollHeight=0;this._text='';}
  addEventListener(type,fn){this.listeners[type]=fn;} append(...items){this.children.push(...items);this.scrollHeight=this.children.length;} appendChild(item){this.append(item);return item;} focus(){} requestSubmit(){if(this.listeners.submit)this.listeners.submit({preventDefault(){}});} set textContent(value){this._text=String(value);this.children=[];} get textContent(){return this._text;}
}
const ids=['jarvis-text-open','jarvis-text-backdrop','jarvis-text-panel','jarvis-text-close','jarvis-text-reset','jarvis-text-messages','jarvis-text-status','jarvis-text-form','jarvis-text-input','jarvis-text-send'];
const elements=Object.fromEntries(ids.map(id=>[id,new FakeElement(id)]));
const document={getElementById:id=>elements[id]||null,createElement:()=>new FakeElement(),createTextNode:value=>({nodeType:3,textContent:String(value)})};
let gatewayCalls=0;
const gateway={getState:()=>({writesEnabled:false,persistentConversation:false,firebaseDirectAccess:false}),send:async()=>{gatewayCalls++;return {answer:'gateway réponse',proposal:null,meta:{writesEnabled:false,outcome:'direct_answer'}};}};
const window={document,navigator:{onLine:true},crypto:crypto.webcrypto,setInterval(){return 1;},addEventListener(){},JarvisGateway:gateway};window.window=window;
const context=vm.createContext({window,document,navigator:window.navigator,crypto:window.crypto,setInterval:window.setInterval,Uint8Array,Date,JSON,Object,Array,Set,String,Error,Promise,Map,Math,RegExp,Intl,db});
for(const id of ['jarvis-security-step2','jarvis-consultation-step5a','jarvis-replenishment-9a','jarvis-consultation-step5b','jarvis-text-step4'])vm.runInContext(script(id),context,{filename:id+'.js'});
const engine=window.JarvisReplenishment9A,broker=window.JarvisReadBroker5B,conversation=window.JarvisConversation;
const results=[];
async function test(name,fn){try{await fn();results.push({name,status:'RÉUSSI'});}catch(error){results.push({name,status:'ÉCHEC',error:`${error.code||error.name}: ${error.message}`});}}
function assert(value,message){if(!value)throw new Error(message||'Assertion échouée');}
function eq(actual,expected,message){if(JSON.stringify(actual)!==JSON.stringify(expected))throw new Error(message||`Attendu ${JSON.stringify(expected)}, reçu ${JSON.stringify(actual)}`);}
function consult(message,pending){return broker.consult('consult.replenishment_rules',{message,pending});}

(async()=>{
  await test('syntaxe des scripts classiques intégrés valide',()=>{const pattern=/<script\b([^>]*)>([\s\S]*?)<\/script>/gi;let match,index=0;while((match=pattern.exec(source))){if(/\bsrc\s*=|\btype\s*=\s*["']module["']/i.test(match[1]))continue;new vm.Script(match[2],{filename:'inline-script-'+(++index)});}assert(index>0);});
  await test('moteur purement consultatif et fermé aux écritures',()=>{assert(engine.getState().writesEnabled===false&&engine.getState().readOnly===true);assert(typeof engine.save==='undefined'&&typeof engine.write==='undefined');assert(window.JarvisSecurity.getAction('consult.replenishment_rules').readOnly===true);});
  await test('objectifs initiaux Hueforge, Figurine et seuil Minimaux avec portée confirmée',()=>{const rules=engine.getDefaultRules();eq(rules.categoryRules.hueforge.targetStock,{value:1,scope:'maison_marche'});eq(rules.categoryRules.figurine.targetStock,{value:3,scope:'maison_marche'});eq(rules.categoryRules.minimaux.alertThreshold,{value:5,scope:'maison_marche'});});
  await test('YouForge et HueForge identifient la catégorie du catalogue',()=>{assert(engine.resolveTarget(db,'objectif des YouForge').category==='Hueforge');assert(engine.resolveTarget(db,'objectif HueForge').category==='Hueforge');});
  await test('Marque-pages et Porte-clés reconnus sans fuzzy matching',()=>{assert(engine.resolveTarget(db,'objectif des marque-pages').category==='Marque Page');assert(engine.resolveTarget(db,'objectif des porte-clés').category==='Porte clefs');});
  await test('catégorie sans règle ne reçoit aucune valeur inventée',()=>{const result=consult('Quel est l’objectif des Lampes ?');assert(/aucune règle/i.test(result.answer),JSON.stringify(result));});
  await test('Hueforge Maison 0 + Marché 1 atteint objectif 1',()=>{const product=db.products[0],rule=engine.resolveRule(db,product);const calc=engine.calculateProduct(product,rule);assert(calc.targetStock===1&&calc.missingToTarget===0&&calc.automaticPrint===false);});
  await test('Hueforge Maison 1 + Marché 1 reste au-dessus de l’objectif sans correction',()=>{const product=db.products[4],rule=engine.resolveRule(db,product);product.stocks.maison=1;product.stocks.marche=1;const calc=engine.calculateProduct(product,rule);assert(calc.targetStock===2&&calc.missingToTarget===0);});
  await test('Hueforge stock connu zéro indique un besoin sans lancer d’impression',()=>{const product=db.products[4];product.stocks.maison=0;product.stocks.marche=0;const calc=engine.calculateProduct(product,engine.resolveRule(db,product));assert(calc.targetStock===0&&calc.missingToTarget===1&&calc.automaticPrint===false);});
  await test('stock inconnu reste inconnu, jamais converti en zéro',()=>{const product={id:99,name:'NOUVEAU',categorie:'Hueforge',stocks:{maison:0}};const calc=engine.calculateProduct(product,engine.resolveRule(db,product));assert(calc.missingToTarget===null&&calc.stockKnown===false);});
  await test('Minimaux seuil 5 alerte à 5 et pas à 6 lorsque portée fournie',()=>{const config=engine.getDefaultRules();config.categoryRules.minimaux.alertThreshold.scope='maison';assert(engine.calculateProduct(db.products[5],engine.resolveRule(db,db.products[5],config)).alertTriggered===true);assert(engine.calculateProduct(db.products[6],engine.resolveRule(db,db.products[6],config)).alertTriggered===false);});
  await test('exception produit prioritaire et retrait rétablit la règle catégorie',()=>{const product=db.products[0],config=engine.getDefaultRules();config.productOverrides['1']={targetStock:{value:4,scope:'maison_marche'}};assert(engine.resolveRule(db,product,config).targetStock.value===4);delete config.productOverrides['1'];assert(engine.resolveRule(db,product,config).targetStock.value===1);});
  await test('quantité à réimprimer reste distincte de l’objectif',()=>{const product=db.products[0],config=engine.getDefaultRules();config.categoryRules.hueforge.replenishQuantity={value:3,scope:null};const rule=engine.resolveRule(db,product,config);assert(rule.targetStock.value===1&&rule.replenishQuantity.value===3);});
  await test('résolution produit ambiguë demande une clarification',()=>{assert(consult('Quel est l’objectif de Dracaufeu ?').outcome==='clarification');});
  await test('clarification par numéro sélectionne uniquement le candidat choisi',()=>{const pending=consult('Quel est l’objectif de Dracaufeu ?').pending;const answer=consult('le premier',pending);assert(answer.outcome==='direct_answer'&&/DRACAUFEU/.test(answer.answer));});
  await test('consultation des objectifs YouForge passe par sendText et le vrai courtier',async()=>{conversation.reset();gatewayCalls=0;const before=JSON.stringify(db);const response=await conversation.sendText('Jarvis, quel est l’objectif des YouForge ?');assert(gatewayCalls===0&&response.answer.includes('1 exemplaire')&&response.answer.includes('Maison + Marché'),JSON.stringify({gatewayCalls,response}));assert(JSON.stringify(db)===before);});
  await test('consultation du seuil Minimaux conserve la portée Maison + Marché confirmée',async()=>{conversation.reset();const response=await conversation.sendText('Jarvis, quel est le seuil des minimaux ?');assert(response.answer.includes('5 pièce')&&/Maison \+ Marché/.test(response.answer));});
  await test('demande de modification est refusée localement sans appel Gateway',async()=>{conversation.reset();gatewayCalls=0;const before=JSON.stringify(db);const response=await conversation.sendText('Jarvis, mets l’objectif des YouForge à deux.');assert(response.outcome==='future_capability'&&/pas encore disponible/i.test(response.answer));assert(gatewayCalls===0&&JSON.stringify(db)===before);});
  await test('les valeurs globales stockAlertSeuil et stockMinDefaut sont inchangées',()=>{assert(db.stockAlertSeuil===3&&db.stockMinDefaut===3);});
  await test('consultation ne modifie ni stock ni finance',()=>{const before=JSON.stringify(db);consult('Quel est l’objectif des YouForge ?');assert(JSON.stringify(db)===before);});
  await test('5B expose la nouvelle consultation sans ouvrir un chemin générique',()=>{assert(broker.getAllowedActions().includes('consult.replenishment_rules'));assert(broker.getState().writesEnabled===false&&broker.getState().genericReadPath===false);assert(typeof broker.getDb==='undefined'&&typeof broker.readPath==='undefined');});
  console.log(JSON.stringify({total:results.length,passed:results.filter(x=>x.status==='RÉUSSI').length,failed:results.filter(x=>x.status==='ÉCHEC').length,results},null,2));
  if(results.some(item=>item.status==='ÉCHEC'))process.exitCode=1;
})();
